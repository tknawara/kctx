"""Run the built-in citation command family."""
from kctx.citations.cli import main

raise SystemExit(main())
