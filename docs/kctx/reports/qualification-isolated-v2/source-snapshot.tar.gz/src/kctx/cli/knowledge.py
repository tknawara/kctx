"""Explicit knowledge collection, approval, publication and pinned retrieval CLI."""
from __future__ import annotations

from pathlib import Path

from kctx.adapters.files.knowledge import load
from kctx.cli.arguments import Arguments
from kctx.cli.registration import ParserRegistrar
from kctx.cli.result import Reply
from kctx.config import Config
from kctx.domain.ids import AuthorityKeyId, PlanId, PolicyDigest, ReleaseId, SourceId, SourceRevision
from kctx.domain.json import object_value
from kctx.errors import KctxError
from kctx.semantics.wire import dec_context, dec_ref
from kctx.services.knowledge import KnowledgeEngine
from kctx.services.knowledge_models import Approval, CaptureKind


def register(subparsers: ParserRegistrar) -> None:
    parser = subparsers.add_parser("knowledge", help="approved canonical knowledge generations")
    commands = parser.add_subparsers(dest="knowledge_command", required=True)
    capture = commands.add_parser("capture", help="retain exact source bytes; never infer prose truth")
    capture.add_argument("--kind", choices=[kind.value for kind in CaptureKind], required=True)
    capture.add_argument("--source", required=True)
    capture.add_argument("--revision", required=True)
    capture.add_argument("--file", required=True)
    capture.add_argument("--observed-at", type=int, required=True)
    propose = commands.add_parser("propose", help="validate explicit candidate against completed predecessor")
    propose.add_argument("--candidate", required=True)
    propose.add_argument("--target-use", required=True)
    propose.add_argument("--now", type=int, required=True)
    sign = commands.add_parser("sign", help="create detached Ed25519 approval with operator-held key")
    sign.add_argument("plan")
    sign.add_argument("--private-key", required=True)
    sign.add_argument("--key-id", required=True)
    admit = commands.add_parser("admit", help="publish exactly the signed candidate")
    admit.add_argument("plan")
    admit.add_argument("--approval", required=True)
    rollback = commands.add_parser("rollback", help="propose an authorized forward retained-snapshot selection")
    rollback.add_argument("--release", required=True)
    rollback.add_argument("--context", required=True)
    rollback.add_argument("--key-id", required=True)
    for command in ("context", "explain"):
        query = commands.add_parser(command)
        query.add_argument("--request", required=True, help="JSON with context and exact claim refs")
        query.add_argument("--release", help="exact completed Git release identity")
        query.add_argument("--limit", type=int, default=20)
        query.add_argument("--continuation")
    commands.add_parser("recover", help="resume durable authenticated operations")
    migrate = commands.add_parser("migrate", help="account, quarantine or stage; never autoapprove")
    migrate.add_argument("--source")
    migrate.add_argument("--apply", action="store_true")
    migrate.add_argument("--rollback")
    migrate.add_argument("--restore-to")
    migrate.add_argument("--migration")
    backup = commands.add_parser("backup")
    backup.add_argument("destination")
    restore = commands.add_parser("restore")
    restore.add_argument("source")


def dispatch(args: Arguments, root: Path) -> Reply:
    config = Config.load()
    if config.knowledge_dir is None:
        raise KctxError("incomplete", "configure knowledge_dir in config.toml")
    anchor = PolicyDigest(config.knowledge_policy_digest) if config.knowledge_policy_digest else None
    engine = KnowledgeEngine(root, config.knowledge_dir, anchor)
    command = args.text("knowledge_command")
    if command == "capture":
        return Reply(engine.capture(CaptureKind(args.text("kind")), SourceId(args.text("source")), SourceRevision(args.text("revision")), Path(args.text("file")).read_bytes(), args.integer("observed_at")).wire())
    if command == "propose":
        return Reply(engine.propose(load(Path(args.text("candidate"))), args.text("target_use"), args.integer("now")).wire())
    if command == "sign":
        return Reply(engine.sign(PlanId(args.text("plan")), Path(args.text("private_key")), AuthorityKeyId(args.text("key_id"))).wire())
    if command == "admit":
        return Reply(engine.admit(PlanId(args.text("plan")), Approval.decode(load(Path(args.text("approval"))))))
    if command == "rollback":
        return Reply(engine.rollback(ReleaseId(args.text("release")), dec_context(load(Path(args.text("context")))), AuthorityKeyId(args.text("key_id"))).wire())
    if command in ("context", "explain"):
        request = load(Path(args.text("request")))
        if set(request) != {"context", "claims"} or not isinstance(request["claims"], list):
            raise KctxError("malformed", "request requires context and claims array")
        claims = tuple(dec_ref(object_value(value)) for value in request["claims"])
        context = dec_context(request["context"])
        release = args.optional_parsed("release", ReleaseId)
        if command == "explain":
            if len(claims) != 1:
                raise KctxError("malformed", "explain requires one exact claim revision")
            return Reply(engine.explain(claims[0], context, release))
        continuation = args.optional_parsed("continuation", lambda value: load(Path(value)))
        return Reply(engine.context(claims, context, args.integer("limit"), continuation, release))
    if command == "recover":
        return Reply(engine.recover())
    if command == "migrate":
        destination = args.optional("restore_to")
        if destination is not None:
            return Reply(engine.restore_migration(PlanId(args.text("migration")), Path(destination)))
        return Reply(engine.migrate(Path(args.text("source")), args.flag("apply"), args.optional_parsed("rollback", PlanId)))
    if command == "backup":
        return Reply(engine.backup(Path(args.text("destination"))))
    if command == "restore":
        return Reply(engine.restore(Path(args.text("source"))))
    raise KctxError("malformed", f"unhandled knowledge command {command!r}")
