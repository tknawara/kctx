"""Production JSONL session acceptance against real native Dolt generations."""

import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import unittest

from _base import KctxTestCase


@unittest.skipUnless(shutil.which("dolt") or (Path.home() / ".local/bin/dolt").is_file(), "native Dolt required")
class QuerySessionIntegrationTest(KctxTestCase):
    def test_pinned_jsonl_requests_publication_and_cancellation(self):
        from kctx.graph import queries, sync
        from kctx.graph.models import GraphNodeId
        from kctx.graph.query_session import MAX_REQUEST_BYTES, QuerySession

        repo = self.make_git_repo("sessions")
        self.set_config(root=str(repo), graph_dir=str(self.root / "graph"))
        self.commit_file(repo, "inventory/assets/A.json", '{"id":"A","name":"A"}\n')
        self.commit_file(repo, "inventory/assets/B.json", '{"id":"B","name":"B"}\n')
        self.commit_file(repo, "inventory/relationships/consumes__B__A.json", '{"from":"B","to":"A","type":"consumes"}\n')
        sync.sync(repo)
        expected = queries.uses(GraphNodeId("A"), kb_root=repo)
        env = dict(os.environ)
        env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
        native_pids = []
        with subprocess.Popen([sys.executable, "-m", "kctx", "query-session"], cwd=repo,
                              stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env) as process:
            try:
                def response():
                    self.assertTrue(select.select([process.stdout], [], [], 60)[0], "session response timed out")
                    line = process.stdout.readline()
                    self.assertTrue(line, "session exited before a response")
                    return json.loads(line)

                def request(op, args=None, ident="request"):
                    process.stdin.write(json.dumps({"schema_version": 1, "id": ident, "op": op, "args": args or {}}).encode() + b"\n")
                    process.stdin.flush()
                    return response()

                ready = response()
                self.assertEqual(ready.get("event"), "ready", ready)
                self.assertGreater(ready["startup_ms"], 0)
                generation = ready["generation"]
                self.assertTrue(generation["is_current_publication"])
                children = Path(f"/proc/{process.pid}/task/{process.pid}/children")
                native_pids = [int(value) for value in children.read_text().split()]
                self.assertTrue(native_pids, "the production session must own a native server")
                self.assertEqual(request("uses", {"target": "A"})["result"], expected)
                self.assertEqual(request("impact", {"target": "A", "depth": 2})["result"]["total"], 1)
                self.assertEqual(request("diff", {"kb_sha_a": "HEAD", "kb_sha_b": "WORKING"})["result"]["sample"], [])
                self.assertTrue(request("status")["ok"])
                origins = request("source-paths", {"target": "A", "revision": generation["kb_sha"]})["result"]
                self.assertEqual(origins["paths"], ["inventory/relationships/consumes__B__A.json"])
                self.assertEqual(origins["dolt_ref"], generation["data_commit"])
                for op, args in (("sql", {"query": "DELETE FROM nodes"}), ("sync", {}),
                                 ("uses", {"target": "A", "limit": 1001}),
                                 ("source-paths", {"target": "A", "limit": 1001}),
                                 ("impact", {"target": "A", "depth": 11}),
                                 ("uses", {"target": "A", "include_illus": "false"})):
                    self.assertFalse(request(op, args)["ok"])
                for malformed in (b"{not json}\n", b"\xff\n", b"[]\n",
                                  b'{"schema_version":2,"id":"bad-version","op":"status"}\n',
                                  b"[" * 2000 + b"]" * 2000 + b"\n"):
                    process.stdin.write(malformed)
                    process.stdin.flush()
                    failure = response()
                    self.assertFalse(failure["ok"])
                    self.assertEqual(failure["schema_version"], 1)
                process.stdin.write(b"x" * (MAX_REQUEST_BYTES + 1) + b"\n")
                process.stdin.flush()
                self.assertFalse(response()["ok"])
                self.assertEqual(request("uses", {"target": "A"})["result"], expected)

                self.commit_file(repo, "inventory/assets/C.json", '{"id":"C","name":"C"}\n')
                self.commit_file(repo, "inventory/relationships/consumes__C__A.json", '{"from":"C","to":"A","type":"consumes"}\n')
                sync.sync(repo)
                pinned = request("uses", {"target": "A"})
                self.assertEqual(pinned["result"], expected)
                self.assertEqual(pinned["generation"]["data_commit"], generation["data_commit"])
                self.assertFalse(pinned["generation"]["is_current_publication"])
                self.assertFalse(request("status")["result"]["up_to_date"])
                process.terminate()
                self.assertEqual(process.wait(timeout=15), 130)
            finally:
                if process.poll() is None:
                    process.kill()
                process.communicate(timeout=15)
        for pid in native_pids:
            self.assertFalse(Path(f"/proc/{pid}").exists(), f"native child leaked: {pid}")
        with QuerySession(repo) as session:
            self.assertEqual(session.uses(GraphNodeId("A"))["total"], 2)
            self.assertTrue(session.identity()["is_current_publication"])
            self.assertNotEqual(session.identity()["data_commit"], generation["data_commit"])
            historical = session.source_paths(GraphNodeId("A"), revision=generation["kb_sha"])
            self.assertEqual(historical["paths"], origins["paths"])
            self.assertEqual(historical["dolt_ref"], generation["data_commit"])
            current = session.source_paths(GraphNodeId("A"), limit=1)
            self.assertEqual(current["total"], 2)
            self.assertEqual(current["returned"], 1)
        with self.assertRaisesRegex(Exception, "not open"):
            session.uses(GraphNodeId("A"))


if __name__ == "__main__":
    unittest.main()
