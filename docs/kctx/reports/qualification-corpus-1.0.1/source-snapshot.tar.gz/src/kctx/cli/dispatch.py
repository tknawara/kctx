"""Route narrowed arguments to typed service command families."""

from pathlib import Path

from kctx.cli import incidents, inventory, proposals, runs
from kctx.cli.arguments import Arguments
from kctx.cli.result import Reply
from kctx.domain.targets import parse_use_target
from kctx.errors import KctxError
from kctx.services import admit, backlinks, context, discovery, freshness, validate


def dispatch(args: Arguments, root: Path) -> Reply:
    command = args.text("command")
    if command == "knowledge":
        from kctx.cli.knowledge import dispatch as knowledge_dispatch

        return knowledge_dispatch(args, root)
    if command in ("asset", "rel", "impact"):
        return inventory.dispatch(args, root)
    if command in ("run", "observe", "cover", "check", "resume", "checkpoint"):
        return runs.dispatch(args, root)
    if command == "proposal":
        return proposals.dispatch(args, root)
    if command in ("dossier", "ktlo", "inv", "sig", "retract", "correction"):
        return incidents.dispatch(args, root)
    if command == "validate":
        result = validate.validate(root)
        return Reply(validate.result_to_wire(result), 0 if result.ok else 1)
    if command == "home":
        home = discovery.home(root, args.text("ident"))
        return Reply(home, 0 if home["candidates"] else 2)
    if command == "context":
        return Reply(context.context(root, args.text("ident"), depth=args.integer("depth")))
    if command == "stale":
        if args.flag("drain"):
            drained = freshness.drain(
                root, project=args.optional("project"), paths=list(args.strings("paths")) or None
            )
            code = (
                3
                if not drained["citations_available"]
                else (0 if drained["total_remaining"] == 0 else 2)
            )
            return Reply(drained, code, presentation="drain")
        return Reply(
            freshness.stale(root, project=args.optional("project"), offline=args.flag("offline"))
        )
    if command == "admit":
        admitted = admit.admit(
            root,
            repo=args.optional("repo"),
            pr_ref=args.optional("pr_ref"),
            since=args.optional("since"),
            dry_run=args.flag("dry_run"),
        )
        return Reply(admitted, admitted["exit_code"])
    if command == "match":
        matched = discovery.match(root, args.text("text"))
        return Reply(
            matched,
            0 if matched["signatures"] or matched["investigations"] or matched["ktlo"] else 2,
        )
    if command == "timeline":
        return Reply(discovery.timeline(root, args.text("ident")))
    if command == "uses":
        uses = backlinks.uses(root, args.parsed("target", parse_use_target))
        return Reply(uses, 0 if uses["referrers"] else 2)
    if command == "graph":
        from kctx.graph.cli_graph import dispatch as graph_dispatch

        payload, code = graph_dispatch(args.namespace, root)
        return Reply(payload, code, presentation="graph")
    if command == "logs":
        from kctx.observability import logs_dispatch

        payload, code = logs_dispatch(args.namespace)
        return Reply(payload, code, presentation="graph")
    raise KctxError("malformed", f"unhandled command {command!r}")
