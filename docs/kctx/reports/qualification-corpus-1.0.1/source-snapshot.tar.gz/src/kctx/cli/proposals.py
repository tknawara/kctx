"""Proposal CLI decoding, service calls, and concrete wire encoders."""

from pathlib import Path

from kctx.adapters.files.mutations import FileRevision
from kctx.cli.arguments import Arguments
from kctx.cli.result import Reply
from kctx.codecs.gates import encode_gate_result
from kctx.codecs.proposals import encode_added, encode_listing, encode_shown, encode_updated
from kctx.domain.ids import GateId, ProposalId, TargetRevision
from kctx.domain.vocabulary import (
    GateOutcome,
    ProposalKind,
    ProposalOrigin,
    ProposalStatus,
    ProposalType,
)
from kctx.errors import KctxError
from kctx.services import proposals


def relative_path(path: Path, root: Path) -> str:
    return str(path.relative_to(root) if path.is_absolute() else path)


def dispatch(args: Arguments, root: Path) -> Reply:
    action = args.text("proposal_command")
    if action == "add":
        types = args.many("type", ProposalType)
        proposal_type = types[0] if len(types) == 1 else types or None
        gates = args.text("gates")
        if gates:
            gates_path = Path(gates)
            try:
                if gates_path.is_file():
                    gates = gates_path.read_text(encoding="utf-8")
            except OSError as exc:
                raise KctxError("malformed", f"cannot read gates: {exc}") from exc
        result = proposals.add(
            root,
            kind=args.parsed("kind", ProposalKind),
            origin=args.parsed("origin", ProposalOrigin),
            type=proposal_type,
            title=args.text("title"),
            target=args.strings("target"),
            context=args.text("context"),
            evidence=args.text("evidence"),
            change=args.text("change"),
            why=args.text("why"),
            research=args.text("research"),
            alternatives=args.text("alternatives"),
            gates=gates,
            impact=args.text("impact"),
            plan=args.text("plan"),
            references=args.strings("references"),
            project=args.optional("project"),
            source_session=args.optional("source_session"),
            proposed_by=args.optional("proposed_by"),
            requested_by=args.optional("requested_by"),
            force=args.flag("force"),
            target_revision=args.optional_parsed("target_revision", TargetRevision),
            environment=args.optional("environment"),
            scope=args.optional("scope"),
        )
        return Reply(
            encode_added(result),
            presentation="proposal-single",
            path=relative_path(result.path, root),
        )
    if action == "list":
        entries = proposals.list_proposals(
            root,
            status=args.optional_parsed("status", ProposalStatus),
            kind=args.optional_parsed("kind", ProposalKind),
            pending_gates=args.flag("pending_gates"),
        )
        return Reply([encode_listing(entry) for entry in entries], presentation="proposal-list")
    proposal_id = args.parsed("id", ProposalId)
    if action == "set":
        updated = proposals.set_status(
            root,
            proposal_id,
            status=args.optional_parsed("status", ProposalStatus),
            by=args.optional("by"),
            note=args.optional("note"),
            superseded_by=args.optional_parsed("superseded_by", ProposalId),
            origin=args.optional_parsed("origin", ProposalOrigin),
            proposed_by=args.optional("proposed_by"),
            requested_by=args.optional("requested_by"),
            swept_at=args.optional("swept_at"),
            landed_add=args.strings("landed_add") or None,
            target_revision=args.optional_parsed("target_revision", TargetRevision),
            expected_revision=args.optional_parsed("expected_revision", FileRevision),
            environment=args.optional("environment"),
            scope=args.optional("scope"),
        )
        path = (
            relative_path(proposals.load(root, proposal_id).path, root)
            if not args.flag("json")
            else ""
        )
        return Reply(encode_updated(updated), presentation="proposal-single", path=path)
    if action == "gate":
        result_gate = proposals.gate(
            root,
            proposal_id,
            args.parsed("gate", GateId),
            outcome=args.parsed("outcome", GateOutcome),
            evidence=args.text("evidence"),
            by=args.optional("by"),
            rev=args.optional("rev"),
            target_revision=args.optional_parsed("target_revision", TargetRevision),
            checker=args.text("checker"),
            expires_at=args.parsed("expires_at", int),
            expected_revision=args.optional_parsed("expected_revision", FileRevision),
            environment=args.optional("environment"),
            scope=args.optional("scope"),
        )
        return Reply(encode_gate_result(result_gate))
    if action == "show":
        return Reply(encode_shown(proposals.show(root, proposal_id)))
    raise KctxError("malformed", f"unhandled proposal command {action!r}")
