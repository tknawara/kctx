"""Qualification metadata cannot silently turn fixture presence into gate evidence."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from qualification_common import Qualification, redacted


class QualificationProtocolTests(unittest.TestCase):
    def test_frozen_balanced_protocol(self):
        directory = ROOT / 'fixtures' / 'qualification'
        protocol_path = directory / 'evaluation-v1.json'
        protocol = json.loads(protocol_path.read_text())
        lock = json.loads((directory / 'protocol-lock.json').read_text())
        self.assertEqual(hashlib.sha256(protocol_path.read_bytes()).hexdigest(), lock['sha256'])
        self.assertEqual(protocol['protocol_version'], '1.0.0')
        tasks = protocol['tasks']
        self.assertGreaterEqual(len(tasks), 24)
        self.assertEqual(len({task['id'] for task in tasks}), len(tasks))
        self.assertEqual({task['project'] for task in tasks}, {'atlas', 'boreal'})
        for project in ('atlas', 'boreal'):
            for category in ('factual', 'review', 'authoring', 'investigation'):
                self.assertEqual(sum(task['project'] == project and task['category'] == category for task in tasks), 3)
        self.assertEqual(protocol['thresholds']['warm_p95_ratio_max'], 1.25)
        self.assertEqual(protocol['thresholds']['maximum_invalid_inferences'], 0)
        self.assertIn('not model quality', protocol['measurement_contract']['mechanical'])

    def test_blocked_case_is_nonzero_and_no_gate_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            q = Qualification('unit-report', Path(directory))
            q.blocked('approved-enterprise-scratch', ['Q61'], 'No approved endpoint')
            self.assertEqual(q.finish(), 1)
            report = json.loads((Path(directory) / 'report.json').read_text())
            self.assertFalse(report['gate_pass'])
            self.assertFalse(report['executed_cases_passed'])
            self.assertEqual(report['cases'][0]['status'], 'blocked')

    def test_executed_success_is_not_whole_gate_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            q = Qualification('unit-report', Path(directory))
            q.case('one-explicit-assertion', [], lambda: {'asserted': 1 == 1})
            self.assertEqual(q.finish(), 0)
            self.assertFalse(q.report['gate_pass'])
            self.assertTrue(q.report['executed_cases_passed'])

    def test_credential_diagnostics_are_redacted(self):
        raw = {'argv': ['tool', '--token', 'private-token-value'],
               'stderr': 'https://user:password@example.invalid token=secret Authorization: Bearer hidden'}
        protected = redacted(raw)
        self.assertNotIn('private-token-value', json.dumps(protected))
        self.assertNotIn('user:password', json.dumps(protected))
        self.assertNotIn('=secret', json.dumps(protected))
        self.assertNotIn('Bearer hidden', json.dumps(protected))

    def test_missing_model_trials_cannot_be_imported_as_success(self):
        from evaluate_kctx import import_agent_receipts
        protocol_path = ROOT / 'fixtures' / 'qualification' / 'evaluation-v1.json'
        protocol = json.loads(protocol_path.read_text())
        identity = hashlib.sha256(protocol_path.read_bytes()).hexdigest()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            receipts = root / 'receipts.json'
            measurements = root / 'measurements.json'
            receipts.write_text(json.dumps({'schema_version':1,'protocol_sha256':identity,'trials':[]}))
            measurements.write_text(json.dumps({'protocol_sha256':identity,'exported_trial_payloads':[]}))
            q = Qualification('unit-import', root / 'report')
            with self.assertRaises(AssertionError):
                import_agent_receipts(q, protocol, receipts, measurements)
            self.assertFalse(q.report['gate_pass'])


if __name__ == '__main__':
    unittest.main()
