"""Run and observation command boundaries."""

from pathlib import Path

from kctx.cli.arguments import Arguments
from kctx.cli.result import Reply
from kctx.codecs.records import (
    encode_coverage_entry,
    encode_observation,
    encode_run_checkpoint,
    encode_run_manifest,
    encode_run_receipt,
    encode_run_resume,
)
from kctx.domain.capture import CoveragePolicy
from kctx.domain.ids import AssetId, ObservationId, RunId, SourceRevision
from kctx.domain.vocabulary import (
    CoverageOutcome,
    ObservationRole,
    ObservationStatus,
    ObservationSystem,
    Readiness,
    RunMode,
)
from kctx.errors import KctxError
from kctx.services import runs


def dispatch(args: Arguments, root: Path) -> Reply:
    command = args.text("command")
    if command == "run":
        return Reply(
            encode_run_manifest(
                runs.new_run(
                    root,
                    project=args.text("project"),
                    mode=args.parsed("mode", RunMode),
                    task=args.text("task"),
                )
            )
        )
    run_id = args.parsed("run", RunId)
    if command == "observe":
        observation = runs.add_observation(
            root,
            run_id,
            system=args.parsed("system", ObservationSystem),
            locator=args.text("locator"),
            asset=args.optional_parsed("asset", AssetId),
            revision=args.optional_parsed("revision", SourceRevision),
            role=args.parsed("role", ObservationRole),
            status=args.parsed("status", ObservationStatus),
            command=args.optional("observed_command"),
            environment=args.optional("environment"),
            evidence=args.optional("evidence"),
            note=args.optional("note"),
            derived_from=args.many("derived_from", ObservationId),
        )
        return Reply(encode_observation(observation))
    if command == "cover":
        entry = runs.cover(
            root,
            run_id,
            item=args.text("item"),
            outcome=args.parsed("outcome", CoverageOutcome),
            evidence=args.many("evidence", ObservationId),
            reason=args.text("reason"),
            policy=args.parsed("policy", CoveragePolicy),
        )
        return Reply(encode_coverage_entry(entry))
    if command == "check":
        receipt = runs.check(root, run_id, require=args.strings("require"))
        code = {Readiness.READY: 0, Readiness.PARTIAL: 2, Readiness.BLOCKED: 3}[receipt.readiness]
        return Reply(encode_run_receipt(receipt), code)
    if command == "resume":
        return Reply(encode_run_resume(runs.resume(root, run_id)))
    if command == "checkpoint":
        return Reply(encode_run_checkpoint(runs.checkpoint(root, run_id, note=args.text("note"))))
    raise KctxError("malformed", f"unhandled run command {command!r}")
