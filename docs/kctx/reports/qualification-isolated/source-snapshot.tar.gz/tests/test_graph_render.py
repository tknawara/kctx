"""Human graph diagnostics render exact binding mismatches, not count records."""

import argparse
from contextlib import redirect_stdout
import io
import unittest

try:
    import structlog
    HAVE_DEPS = True
except ImportError:
    HAVE_DEPS = False


@unittest.skipUnless(HAVE_DEPS, "structlog not installed; run via uv run")
class GraphParityRenderTest(unittest.TestCase):
    def test_exact_mismatch_reports_changed_revision(self):
        from kctx.graph.render import render_graph_text

        result = {
            "parity": {
                "match": False, "kb_sha": "a" * 40,
                "direct_cite_tokens": 1, "graph_binding_rows": 1,
                "skipped_tokens": 0, "direct_illus_tokens": 0,
                "graph_illus_rows": 0, "binding_mismatch_count": 1,
                "inputs_match": True, "diagnostic_count": 0,
                "diagnostics_truncated": False, "skips": [],
                "binding_mismatches": [{
                    "edge_id": "binding",
                    "expected": {"src_path": "note.md", "src_line": 2, "rev": "correct"},
                    "actual": {"src_path": "note.md", "src_line": 2, "rev": "wrong"},
                }],
            },
            "uses_comparison": [],
        }
        stream = io.StringIO()
        with redirect_stdout(stream):
            render_graph_text(argparse.Namespace(command="graph", graph_command="check"), result)
        rendered = stream.getvalue()
        self.assertIn("MISMATCH", rendered)
        self.assertIn("note.md:2", rendered)
        self.assertIn("rev: expected='correct' actual='wrong'", rendered)
