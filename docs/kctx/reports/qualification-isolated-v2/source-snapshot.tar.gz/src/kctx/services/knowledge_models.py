"""Typed source collection and authenticated admission records."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from kctx.domain.ids import AuthorityKeyId, ContentDigest, ContentId, PlanId, PolicyDigest, ReleaseId, SourceCaptureId, SourceId, SourceRevision
from kctx.domain.json import JsonObject, integer, text
from kctx.semantics.model import Context, Plan, SelectionPlan
from kctx.semantics.wire import dec_context, dec_plan, enc_context, enc_plan, dec_selection_plan, enc_selection_plan
from kctx.domain.json import object_value


class CaptureKind(Enum):
    SOURCE = "source"
    PR = "pr"
    DOCUMENT = "document"


@dataclass(frozen=True, slots=True)
class SourceCapture:
    id: SourceCaptureId
    kind: CaptureKind
    source: SourceId
    revision: SourceRevision
    content: ContentDigest
    observed_at: int

    @property
    def content_identity(self) -> ContentId:
        """Project a retained SHA256 artifact into the opaque semantic identity."""
        return ContentId(self.content.val)

    def wire(self) -> JsonObject:
        return {"id": self.id.val, "kind": self.kind.value, "source": self.source.val, "revision": self.revision.val, "content": self.content.val, "observed_at": self.observed_at}

    @classmethod
    def decode(cls, value: JsonObject) -> SourceCapture:
        if set(value) != {"id", "kind", "source", "revision", "content", "observed_at"}:
            raise ValueError("invalid capture record fields")
        return cls(SourceCaptureId(text(value["id"], "id")), CaptureKind(text(value["kind"], "kind")), SourceId(text(value["source"], "source")), SourceRevision(text(value["revision"], "revision")), ContentDigest(text(value["content"], "content")), integer(value["observed_at"], "observed_at"))


@dataclass(frozen=True, slots=True)
class AdmissionPlan:
    id: PlanId
    base: ReleaseId | None
    policy: PolicyDigest
    captures: tuple[SourceCaptureId, ...]
    context: Context
    semantic: Plan

    @property
    def actor(self) -> AuthorityKeyId:
        return AuthorityKeyId(self.semantic.authority.actor.val)

    def wire(self) -> JsonObject:
        return {"schema_version": 2, "kind": "admission", "id": self.id.val, "base": self.base.val if self.base else None, "policy": self.policy.val, "captures": [item.val for item in self.captures], "context": object_value(enc_context(self.context)), "plan": object_value(enc_plan(self.semantic))}

    @classmethod
    def decode(cls, value: JsonObject) -> AdmissionPlan:
        if set(value) != {"schema_version", "kind", "id", "base", "policy", "captures", "context", "plan"} or value["kind"] != "admission":
            raise ValueError("invalid admission plan fields")
        captures = value["captures"]
        if value.get("schema_version") != 2 or not isinstance(captures, list):
            raise ValueError("invalid admission plan schema")
        return cls(PlanId(text(value["id"], "id")), ReleaseId(text(value["base"], "base")) if value["base"] else None, PolicyDigest(text(value["policy"], "policy")), tuple(SourceCaptureId(text(item, "capture")) for item in captures), dec_context(value["context"]), dec_plan(value["plan"]))


@dataclass(frozen=True, slots=True)
class ReleaseSelectionPlan:
    id: PlanId
    base: ReleaseId
    retained: ReleaseId
    policy: PolicyDigest
    context: Context
    semantic: SelectionPlan

    @property
    def actor(self) -> AuthorityKeyId:
        actor = self.semantic.actor
        if actor is None:
            raise ValueError("retained selection requires an approving actor")
        return AuthorityKeyId(actor.val)

    def wire(self) -> JsonObject:
        return {"schema_version": 2, "kind": "selection", "id": self.id.val, "base": self.base.val, "retained": self.retained.val, "policy": self.policy.val, "context": object_value(enc_context(self.context)), "plan": object_value(enc_selection_plan(self.semantic))}

    @classmethod
    def decode(cls, value: JsonObject) -> ReleaseSelectionPlan:
        if set(value) != {"schema_version", "kind", "id", "base", "retained", "policy", "context", "plan"} or value["schema_version"] != 2 or value["kind"] != "selection":
            raise ValueError("invalid retained-selection plan schema")
        return cls(PlanId(text(value["id"], "id")), ReleaseId(text(value["base"], "base")), ReleaseId(text(value["retained"], "retained")), PolicyDigest(text(value["policy"], "policy")), dec_context(value["context"]), dec_selection_plan(value["plan"]))


def decode_operation(value: JsonObject) -> AdmissionPlan | ReleaseSelectionPlan:
    if value.get("kind") == "admission":
        return AdmissionPlan.decode(value)
    if value.get("kind") == "selection":
        return ReleaseSelectionPlan.decode(value)
    raise ValueError("unknown knowledge operation kind")


@dataclass(frozen=True, slots=True)
class Approval:
    plan: PlanId
    key: AuthorityKeyId
    signature: bytes

    def wire(self) -> JsonObject:
        return {"schema_version": 2, "plan": self.plan.val, "key": self.key.val, "signature": self.signature.hex()}

    @classmethod
    def decode(cls, value: JsonObject) -> Approval:
        if set(value) != {"schema_version", "plan", "key", "signature"} or value["schema_version"] != 2:
            raise ValueError("invalid approval envelope")
        return cls(PlanId(text(value["plan"], "plan")), AuthorityKeyId(text(value["key"], "key")), bytes.fromhex(text(value["signature"], "signature")))
