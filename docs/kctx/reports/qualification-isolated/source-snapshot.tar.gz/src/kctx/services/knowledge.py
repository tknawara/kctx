"""Authenticated source-to-admission publication and pinned retrieval.

Git's completed ref is the only publication point. Native Dolt candidate commits
and retained Git objects are durable before its expected-predecessor CAS. The
local lock coordinates cooperating writers; it is not a cross-store transaction.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace
from importlib.metadata import version
from pathlib import Path
import platform
import shutil
import time

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from kctx.adapters.dolt.knowledge import KnowledgeDolt
from kctx.adapters.dolt.native import restore_backup
from kctx.adapters.files.knowledge import canonical, decode, digest, durable_unlink, durable_write, load, save, writer_lock
from kctx.adapters.git.knowledge import GitReleases, RELEASE_REF
from kctx.domain.ids import AuthorityKeyId, ContentDigest, DoltCommitId, OperationId, PlanId, PolicyDigest, ReleaseId, SnapshotId, SourceCaptureId
from kctx.domain.json import JsonObject, JsonValue, object_value, text
from kctx.errors import KctxError
from kctx.semantics.model import Authority, ClaimRef, CommitOutcome, Context, KB, Plan, ReceiptResult, SelectionPlan, SelectionState, SourceSelection, VerifiedApproval, VerifiedSelectionApproval, find_claim, narrower
from kctx.semantics.checker import accepted, assess
from kctx.semantics.wellformed import well_formed
from kctx.semantics.workflow import apply_plan, plan_valid, apply_selection, selection_plan_valid
from kctx.semantics.wire import dec_context, dec_kb, dec_ref, dec_source_selection, dec_witness, enc_assessment, enc_context, enc_kb, enc_ref, enc_source_selection
from kctx.services.knowledge_models import AdmissionPlan, ReleaseSelectionPlan, Approval, CaptureKind, SourceCapture, decode_operation
from kctx.services.knowledge_migration import Disposition, inspect_legacy, safe_restore_path

TOOLCHAIN = "kctx-semantic-2.0.0"


class KnowledgeEngine:
    def __init__(self, repo: Path, store: Path, trusted_policy_digest: PolicyDigest | None = None, *, fault: Callable[[str], None] | None = None) -> None:
        self.git = GitReleases(repo)
        self.store = KnowledgeDolt(store)
        self.root = self.git.common / "kctx-knowledge"
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = self.store.path.parent / (self.store.path.name + ".knowledge.lock")
        owner_path = self.store.path.parent / (self.store.path.name + ".knowledge-owner.json")
        owner: JsonObject = {"schema_version": 2, "git_common": str(self.git.common)}
        with writer_lock(self.lock):
            if owner_path.exists() and load(owner_path) != owner:
                raise KctxError("conflict", "native Dolt store is owned by another authored repository")
            save(owner_path, owner)
        self.bootstrap = trusted_policy_digest
        self.fault = fault

    def _artifact(self, identity: ContentDigest, release: ReleaseId | None = None) -> bytes:
        path = self.root / "artifacts" / identity.val
        if path.is_file():
            data = path.read_bytes()
        elif release:
            data = self.git.artifact(release.val, identity.val)
        else:
            raise KctxError("not-found", f"missing retained artifact {identity.val}")
        if digest(data) != identity.val:
            raise KctxError("conflict", "retained content digest mismatch")
        return data

    def _retain(self, data: bytes) -> ContentDigest:
        identity = ContentDigest(digest(data))
        durable_write(self.root / "artifacts" / identity.val, data)
        return identity

    def _policy(self, release: ReleaseId | None) -> tuple[PolicyDigest, JsonObject]:
        if release:
            identity = PolicyDigest(text(self.git.manifest(release.val)["policy"], "policy"))
            data = self._artifact(ContentDigest(identity.val), release)
            if self.bootstrap is None or identity != self.bootstrap:
                raise KctxError("conflict", "release policy does not match configured trust anchor")
        else:
            if self.bootstrap is None:
                raise KctxError("conflict", "bootstrap requires configured knowledge_policy_digest trust anchor")
            data = (self.git.repo / ".kctx" / "knowledge-policy.json").read_bytes()
            identity = PolicyDigest(digest(data))
            if identity != self.bootstrap:
                raise KctxError("conflict", "bootstrap policy does not match configured trust anchor")
            self._retain(data)
        policy = decode(data)
        if set(policy) != {"schema_version", "kb_id", "policy_version", "trusted_keys"} or policy["schema_version"] != 2:
            raise KctxError("malformed", "unsupported authority policy schema")
        if not text(policy["kb_id"], "kb_id") or not text(policy["policy_version"], "policy_version"):
            raise KctxError("malformed", "empty policy identity")
        object_value(policy["trusted_keys"])
        return identity, policy

    def _current(self) -> ReleaseId | None:
        current = self.git.current()
        return ReleaseId(current) if current else None

    def _base(self, release: ReleaseId | None, policy: JsonObject) -> KB:
        if release is None:
            return KB(SnapshotId("bootstrap:" + text(policy["kb_id"], "kb_id")))
        manifest = self.git.manifest(release.val)
        if manifest.get("schema_version") != 2 or manifest.get("toolchain") != TOOLCHAIN:
            raise KctxError("malformed", "unsupported release schema/toolchain")
        kb = dec_kb(self.store.read(DoltCommitId(text(manifest["dolt_commit"], "dolt_commit")), text(policy["kb_id"], "kb_id")))
        plan = decode_operation(decode(self._artifact(ContentDigest(text(manifest["plan_artifact"], "plan_artifact")), release)))
        approval = Approval.decode(decode(self._artifact(ContentDigest(text(manifest["approval_artifact"], "approval_artifact")), release)))
        self._verify(plan, approval, policy_source=release)
        if self._identity(plan) != plan.id or manifest["operation"] != plan.id.val or manifest["predecessor"] != (plan.base.val if plan.base else None) or manifest["snapshot"] != kb.snapshot.val:
            raise KctxError("conflict", "pinned generation differs from authenticated complete plan")
        if not well_formed(kb):
            raise KctxError("conflict", "pinned generation is not well formed")
        self._assert_unused_snapshot(kb.snapshot, plan.base)
        if self._sources(release) != plan.context.sources:
            raise KctxError("conflict", "release source selection differs from authenticated context")
        predecessor = self._base(plan.base, policy)
        if isinstance(plan, AdmissionPlan):
            if plan.semantic.candidate != kb or plan.semantic.expected_snapshot != predecessor.snapshot or not plan_valid(predecessor, plan.context, plan.semantic):
                raise KctxError("conflict", "retained signed candidate is not a valid conditional admission")
            self._validate_sources(plan, predecessor, policy, capture_release=release)
            expected_selected = self._selected(plan.base) + tuple(claim.ref for claim in kb.claims[len(predecessor.claims):])
        else:
            retained = self._base(plan.retained, policy)
            state = SelectionState(predecessor, self._selected(plan.base))
            self._validate_policy_context(plan.context, policy)
            if plan.context.sources != self._sources(plan.base):
                raise KctxError("conflict", "retained selection changed current source identities")
            if not selection_plan_valid(state, plan.context, plan.semantic, retained=(retained,)) or kb != replace(predecessor, snapshot=plan.semantic.new_snapshot) or manifest.get("retained_release") != plan.retained.val:
                raise KctxError("conflict", "retained selection violates authenticated ledger-preservation law")
            expected_selected = plan.semantic.selected
            prior_manifest = self.git.manifest(plan.base.val)
            if self.store.rows("captures", DoltCommitId(text(manifest["dolt_commit"], "dolt_commit"))) != self.store.rows("captures", DoltCommitId(text(prior_manifest["dolt_commit"], "dolt_commit"))):
                raise KctxError("conflict", "selection altered retained source captures")
        if self._selected(release) != expected_selected:
            raise KctxError("conflict", "release active view differs from authenticated operation")
        return kb

    def capture(self, kind: CaptureKind, source: str, revision: str, content: bytes, observed_at: int) -> SourceCapture:
        if not isinstance(kind, CaptureKind) or not source or not revision or observed_at < 0:
            raise KctxError("malformed", "capture requires typed kind, exact supplied source revision and nonnegative time")
        with writer_lock(self.lock):
            self._policy(self._current())
            return self._capture_bytes(kind, source, revision, content, observed_at)

    def _capture_bytes(self, kind: CaptureKind, source: str, revision: str, content: bytes, observed_at: int) -> SourceCapture:
        content_id = self._retain(content)
        metadata: JsonObject = {"kind": kind.value, "source": source, "revision": revision, "content": content_id.val, "observed_at": observed_at}
        identity = SourceCaptureId(digest(canonical(metadata)))
        capture = SourceCapture(identity, kind, source, revision, content_id, observed_at)
        save(self.root / "captures" / (identity.val + ".json"), capture.wire())
        return capture

    def _capture(self, identity: SourceCaptureId, release: ReleaseId | None) -> SourceCapture:
        path = self.root / "captures" / (identity.val + ".json")
        if path.is_file():
            capture = SourceCapture.decode(load(path))
        elif release:
            manifest = self.git.manifest(release.val)
            rows = self.store.rows("captures", DoltCommitId(text(manifest["dolt_commit"], "dolt_commit")))
            found = next((row for row in rows if row["id"] == identity.val), None)
            if found is None:
                raise KctxError("not-found", "capture is not retained in pinned generation")
            capture = SourceCapture.decode(found)
        else:
            raise KctxError("not-found", "capture metadata missing")
        metadata = capture.wire()
        del metadata["id"]
        if capture.id != identity or digest(canonical(metadata)) != identity.val:
            raise KctxError("conflict", "capture identity mismatch")
        self._artifact(capture.content, release)
        return capture

    def _validate_sources(self, plan: AdmissionPlan, base: KB, policy: JsonObject, *, capture_release: ReleaseId | None = None) -> tuple[SourceCapture, ...]:
        capture_release = capture_release or plan.base
        captures = tuple(self._capture(identity, capture_release) for identity in plan.captures)
        if len(set(plan.captures)) != len(plan.captures):
            raise KctxError("malformed", "duplicate capture identity")
        for observation in plan.semantic.candidate.observations:
            matching = [capture for capture in captures if capture.source == observation.source and capture.revision == observation.revision and capture.observed_at == observation.observed_at]
            if not any(observation.content == capture.content.val or (observation.content.startswith("inventory:") and self._artifact(capture.content, capture_release) == observation.content.encode()) for capture in matching):
                raise KctxError("conflict", "observation lacks exact retained capture provenance")
        for attestation in plan.semantic.candidate.attestations[len(base.attestations):]:
            if attestation.authority != plan.semantic.authority.actor:
                raise KctxError("conflict", "new attestation is not bound to approving authority")
        previous = {item.source: item for item in self._sources(plan.base)}
        selected = {item.source: item for item in plan.context.sources}
        if len(selected) != len(plan.context.sources) or previous.keys() - selected.keys():
            raise KctxError("conflict", "source selection duplicates or drops a previously selected source")
        prior_capture_ids: set[SourceCaptureId] = set()
        if plan.base:
            prior_manifest = self.git.manifest(plan.base.val)
            prior_capture_ids = {SourceCaptureId(text(row["id"], "capture id")) for row in self.store.rows("captures", DoltCommitId(text(prior_manifest["dolt_commit"], "dolt_commit")))}
        for selection in plan.context.sources:
            matching = tuple(capture for capture in captures if capture.source == selection.source and capture.revision == selection.revision and (capture.content.val == selection.content or (selection.content.startswith("inventory:") and self._artifact(capture.content, capture_release) == selection.content.encode())))
            if not matching:
                raise KctxError("conflict", "selected source identity has no exact retained capture")
            if selection.source in previous and selection != previous[selection.source] and not any(capture.id not in prior_capture_ids for capture in matching):
                raise KctxError("conflict", "source replacement requires an explicit new capture, not an old retained observation")
        self._validate_receipts(plan, base)
        self._validate_policy_context(plan.context, policy)
        return captures

    def _validate_policy_context(self, context: Context, policy: JsonObject) -> None:
        if context.policy.id.val != policy["policy_version"]:
            raise KctxError("conflict", "semantic policy identity differs from trusted authority policy")
        allowed = tuple(sorted(key for key, value in object_value(policy["trusted_keys"]).items() if context.intended_use in self._list(object_value(value)["target_uses"])))
        if tuple(sorted(context.policy.authorized_actors)) != allowed:
            raise KctxError("conflict", "semantic authorized actors differ from trusted policy projection")

    @staticmethod
    def _validate_receipts(plan: AdmissionPlan, base: KB) -> None:
        execution_context = replace(plan.context, snapshot=plan.semantic.candidate.snapshot)
        for receipt in plan.semantic.candidate.receipts[len(base.receipts):]:
            if receipt.context != execution_context or receipt.context.checker.val != "kctx-2" or receipt.expires_at < execution_context.now:
                raise KctxError("conflict", "new receipt must bind this actual named-checker execution context")
            checked = next((result for witness, result in accepted(plan.semantic.candidate, execution_context, receipt.claim) if witness == receipt.witness), None)
            actual_result = ReceiptResult.PASS if checked is not None else ReceiptResult.FAIL
            actual_dependencies = checked.dependencies if checked is not None else ()
            if receipt.result is not actual_result or receipt.dependencies != actual_dependencies:
                raise KctxError("conflict", "caller receipt differs from actual named-checker result or computed dependencies")

    def _sources(self, release: ReleaseId | None) -> tuple[SourceSelection, ...]:
        if release is None:
            return ()
        return tuple(dec_source_selection(value) for value in self._list(self.git.manifest(release.val)["sources"]))

    def _assert_unused_snapshot(self, snapshot: SnapshotId, base: ReleaseId | None) -> None:
        cursor = base
        while cursor is not None:
            manifest = self.git.manifest(cursor.val)
            if manifest["snapshot"] == snapshot.val:
                raise KctxError("conflict", "immutable snapshot identity was already used by a completed release")
            predecessor = manifest["predecessor"]
            cursor = ReleaseId(text(predecessor, "predecessor")) if predecessor is not None else None

    def _require_completed(self, release: ReleaseId) -> None:
        cursor = self._current()
        while cursor is not None:
            if cursor == release:
                return
            predecessor = self.git.manifest(cursor.val)["predecessor"]
            cursor = ReleaseId(text(predecessor, "predecessor")) if predecessor is not None else None
        raise KctxError("not-found", "release is not in the completed publication history")

    def _selected(self, release: ReleaseId | None) -> tuple[ClaimRef, ...]:
        if release is None:
            return ()
        return tuple(dec_ref(value) for value in self._list(self.git.manifest(release.val)["selected"]))

    def rollback(self, retained_release: ReleaseId, context: Context, authority_key: AuthorityKeyId) -> ReleaseSelectionPlan:
        """Propose a signed forward selection, never rewind a completed pointer."""
        with writer_lock(self.lock):
            base_release = self._current()
            if base_release is None:
                raise KctxError("not-found", "retained selection requires a completed predecessor")
            self._require_completed(retained_release)
            policy_id, policy = self._policy(base_release)
            base = self._base(base_release, policy)
            retained = self._base(retained_release, policy)
            self._validate_policy_context(context, policy)
            if context.sources != self._sources(base_release):
                raise KctxError("conflict", "rollback must preserve current source selections")
            self._key(policy, authority_key, context.intended_use)
            material: JsonObject = {"base": base_release.val, "retained": retained_release.val, "context": object_value(enc_context(context)), "actor": authority_key.val, "policy": policy_id.val}
            snapshot = SnapshotId("selection:" + digest(canonical(material)))
            self._assert_unused_snapshot(snapshot, base_release)
            semantic = SelectionPlan(OperationId("pending"), base.snapshot, retained.snapshot, snapshot, tuple(claim.ref for claim in retained.claims), authority_key.val, context.policy.id, context.intended_use, context=context)
            plan = ReleaseSelectionPlan(PlanId("0" * 64), base_release, retained_release, policy_id, context, semantic)
            identity = self._identity(plan)
            plan = replace(plan, id=identity, semantic=replace(semantic, id=OperationId(identity.val)))
            if not selection_plan_valid(SelectionState(base, self._selected(base_release)), context, plan.semantic, retained=(retained,)):
                raise KctxError("conflict", "retained snapshot is not a compatible authorized selection")
            save(self.root / "plans" / (identity.val + ".json"), plan.wire())
            return plan

    @staticmethod
    def _identity(plan: AdmissionPlan | ReleaseSelectionPlan) -> PlanId:
        record = plan.wire()
        del record["id"]
        semantic = object_value(record["plan"])
        del semantic["id"]
        record["plan"] = semantic
        return PlanId(digest(canonical(record)))

    def propose(self, candidate: JsonObject, target_use: str, now: int) -> AdmissionPlan:
        if set(candidate) != {"kb", "capture_ids", "context", "claim", "witness", "authority_key"}:
            raise KctxError("malformed", "candidate requires kb,capture_ids,context,claim,witness,authority_key")
        with writer_lock(self.lock):
            base_release = self._current()
            policy_id, policy = self._policy(base_release)
            base = self._base(base_release, policy)
            kb = dec_kb(candidate["kb"])
            self._assert_unused_snapshot(kb.snapshot, base_release)
            context = dec_context(candidate["context"])
            if context.snapshot != base.snapshot or context.now != now or context.intended_use != target_use:
                raise KctxError("conflict", "proposal context must identify exact base, time and intended use")
            claim = dec_ref(candidate["claim"])
            record = find_claim(kb, claim)
            if record is None:
                raise KctxError("malformed", "designated candidate claim missing")
            actor = AuthorityKeyId(text(candidate["authority_key"], "authority_key"))
            authority = Authority(actor=actor.val, target=claim, intended_use=target_use, policy=context.policy.id, statement=record.statement, approved=kb, approvals=kb.claims[len(base.claims):], context=context)
            raw_ids = candidate["capture_ids"]
            if not isinstance(raw_ids, list):
                raise KctxError("malformed", "capture_ids must be an array")
            placeholder = PlanId("0" * 64)
            semantic = Plan(OperationId(placeholder.val), base.snapshot, kb, authority, claim, dec_witness(candidate["witness"]))
            plan = AdmissionPlan(placeholder, base_release, policy_id, tuple(SourceCaptureId(text(item, "capture_id")) for item in raw_ids), context, semantic)
            identity = self._identity(plan)
            plan = replace(plan, id=identity, semantic=replace(semantic, id=OperationId(identity.val)))
            self._key(policy, actor, target_use)
            self._validate_sources(plan, base, policy)
            if not plan_valid(base, context, plan.semantic):
                raise KctxError("conflict", "candidate rejected by calculus preflight")
            save(self.root / "plans" / (identity.val + ".json"), plan.wire())
            return plan

    def _plan(self, identity: PlanId) -> AdmissionPlan | ReleaseSelectionPlan:
        plan = decode_operation(load(self.root / "plans" / (identity.val + ".json")))
        if plan.id != identity or self._identity(plan) != identity or plan.semantic.id.val != identity.val:
            raise KctxError("conflict", "plan content does not match canonical identity")
        return plan

    @staticmethod
    def _key(policy: JsonObject, identity: AuthorityKeyId, target_use: str) -> Ed25519PublicKey:
        keys = object_value(policy["trusted_keys"])
        if identity.val not in keys:
            raise KctxError("conflict", "untrusted approving key")
        key = object_value(keys[identity.val])
        if set(key) != {"public_key", "target_uses"} or not isinstance(key["target_uses"], list) or target_use not in key["target_uses"]:
            raise KctxError("conflict", "authority key is not authorized for intended use")
        return Ed25519PublicKey.from_public_bytes(bytes.fromhex(text(key["public_key"], "public_key")))

    def sign(self, identity: PlanId, private_key: Path, key_id: AuthorityKeyId) -> Approval:
        plan = self._plan(identity)
        if plan.actor != key_id:
            raise KctxError("conflict", "signer is not designated proposal authority")
        key = serialization.load_pem_private_key(private_key.read_bytes(), password=None)
        if not isinstance(key, Ed25519PrivateKey):
            raise KctxError("malformed", "approval requires Ed25519 PEM private key")
        approval = Approval(identity, key_id, key.sign(b"kctx-operation-v2\x00" + canonical(plan.wire())))
        self._verify(plan, approval)
        return approval

    def _verify(self, plan: AdmissionPlan | ReleaseSelectionPlan, approval: Approval, *, policy_source: ReleaseId | None = None) -> tuple[JsonObject, VerifiedApproval | VerifiedSelectionApproval]:
        identity, policy = self._policy(policy_source or plan.base)
        if identity != plan.policy or approval.plan != plan.id or approval.key != plan.actor:
            raise KctxError("conflict", "approval is bound to different plan, policy or actor")
        declared_context = plan.semantic.authority.context if isinstance(plan, AdmissionPlan) else plan.semantic.context
        if declared_context != plan.context:
            raise KctxError("conflict", "signed semantic operation and service context differ")
        try:
            self._key(policy, approval.key, plan.context.intended_use).verify(approval.signature, b"kctx-operation-v2\x00" + canonical(plan.wire()))
        except InvalidSignature as exc:
            raise KctxError("conflict", "invalid detached approval signature") from exc
        return policy, VerifiedApproval(plan.semantic) if isinstance(plan, AdmissionPlan) else VerifiedSelectionApproval(plan.semantic)

    def _phase(self, journal: JsonObject, phase: str) -> None:
        journal["phase"] = phase
        save(self.root / "journal" / (text(journal["id"], "id") + ".json"), journal)
        if self.fault is not None:
            self.fault(phase)

    def admit(self, identity: PlanId, approval: Approval) -> JsonObject:
        with writer_lock(self.lock):
            plan = self._plan(identity)
            self._verify(plan, approval)
            path = self.root / "journal" / (identity.val + ".json")
            if path.exists():
                journal = load(path)
                if journal.get("approval") != approval.wire():
                    raise KctxError("conflict", "conflicting operation replay")
            else:
                journal = {"schema_version": 2, "id": identity.val, "approval": approval.wire(), "phase": "prepared"}
                if self._current() != plan.base:
                    raise KctxError("conflict", "expected predecessor changed")
                self._phase(journal, "prepared")
            return self._finish(plan, approval, journal)

    def _finish(self, plan: AdmissionPlan | ReleaseSelectionPlan, approval: Approval, journal: JsonObject) -> JsonObject:
        policy, verified = self._verify(plan, approval)
        current = self._current()
        release_value = journal.get("release")
        release = ReleaseId(text(release_value, "release")) if release_value else None
        if release and current == release:
            self._phase(journal, "published")
            return {"outcome": "already_applied", "release": release.val, "plan": plan.id.val}
        if current != plan.base:
            # A later completed generation can retain this exact operation in
            # its immutable release ancestry; it is not a conflicting replay.
            cursor = current
            while cursor:
                manifest = self.git.manifest(cursor.val)
                if manifest.get("operation") == plan.id.val:
                    return {"outcome": "already_applied", "release": cursor.val, "plan": plan.id.val}
                predecessor = manifest.get("predecessor")
                cursor = ReleaseId(text(predecessor, "predecessor")) if predecessor else None
            raise KctxError("conflict", "expected predecessor changed; previous release remains published")
        base = self._base(plan.base, policy)
        if isinstance(plan, AdmissionPlan):
            if not isinstance(verified, VerifiedApproval):
                raise KctxError("conflict", "wrong verified operation capability")
            captures = self._validate_sources(plan, base, policy)
            result = apply_plan(base, plan.context, (), plan.semantic, trusted_approvals=(verified,))
            if result.outcome is not CommitOutcome.APPLIED:
                raise KctxError("conflict", "complete approved candidate failed semantic validation")
            candidate_kb = result.kb
            selected = self._selected(plan.base) + tuple(claim.ref for claim in candidate_kb.claims[len(base.claims):])
        else:
            if not isinstance(verified, VerifiedSelectionApproval):
                raise KctxError("conflict", "wrong verified operation capability")
            self._validate_policy_context(plan.context, policy)
            if plan.context.sources != self._sources(plan.base):
                raise KctxError("conflict", "rollback must preserve current source selections")
            target = self._base(plan.retained, policy)
            selection = apply_selection(SelectionState(base, self._selected(plan.base)), plan.context, (), plan.semantic, trusted_approvals=(verified,), retained=(target,))
            if selection.outcome is not CommitOutcome.APPLIED:
                raise KctxError("conflict", "approved retained selection failed semantic validation")
            candidate_kb = selection.state.kb
            selected = selection.state.selected
            prior_manifest = self.git.manifest(plan.base.val)
            captures = tuple(SourceCapture.decode(row) for row in self.store.rows("captures", DoltCommitId(text(prior_manifest["dolt_commit"], "dolt_commit"))))
        self._assert_unused_snapshot(candidate_kb.snapshot, plan.base)
        if "dolt_commit" not in journal:
            prior = self.git.manifest(plan.base.val) if plan.base else None
            commit = self.store.commit_candidate(plan.id, DoltCommitId(text(prior["dolt_commit"], "dolt_commit")) if prior else None, object_value(enc_kb(candidate_kb)), [capture.wire() for capture in captures], {"id": plan.id.val, "actor": approval.key.val, "signature": approval.signature.hex(), "policy": plan.policy.val, "target_use": plan.context.intended_use, "base": plan.base.val if plan.base else None}, text(policy["kb_id"], "kb_id"))
            if self.fault is not None:
                self.fault("after_candidate_commit")
            journal["dolt_commit"] = commit.val
            self._phase(journal, "candidate")
        commit = DoltCommitId(text(journal["dolt_commit"], "dolt_commit"))
        retained = dec_kb(self.store.read(commit, text(policy["kb_id"], "kb_id")))
        if retained != candidate_kb or not well_formed(retained):
            raise KctxError("conflict", "completed native candidate differs from approved state")
        if release is None:
            artifacts = {capture.content.val: self._artifact(capture.content, plan.base) for capture in captures}
            artifacts[plan.policy.val] = self._artifact(ContentDigest(plan.policy.val), plan.base)
            plan_content = canonical(plan.wire())
            approval_content = canonical(approval.wire())
            artifacts[digest(plan_content)] = plan_content
            artifacts[digest(approval_content)] = approval_content
            semantic_sources: JsonObject = {path.name: digest(path.read_bytes()) for path in sorted((Path(__file__).parents[1] / "semantics").glob("*.py"))}
            toolchain = canonical({"semantic_sources": semantic_sources, "python": platform.python_version(), "cryptography": version("cryptography"), "dolt": self.store.run("version").strip(), "git": self.git.run("--version").strip()})
            artifacts[digest(toolchain)] = toolchain
            manifest: JsonObject = {"schema_version": 2, "semantic_version": "2.0.0", "snapshot": retained.snapshot.val, "kb_id": policy["kb_id"], "operation": plan.id.val, "predecessor": plan.base.val if plan.base else None, "dolt_commit": commit.val, "policy": plan.policy.val, "toolchain": TOOLCHAIN, "artifacts": sorted(artifacts), "plan_artifact": digest(plan_content), "approval_artifact": digest(approval_content)}
            manifest["toolchain_artifact"] = digest(toolchain)
            manifest["selected"] = [object_value(enc_ref(ref)) for ref in selected]
            manifest["sources"] = [object_value(enc_source_selection(source)) for source in plan.context.sources]
            manifest["operation_kind"] = "admission" if isinstance(plan, AdmissionPlan) else "selection"
            if isinstance(plan, ReleaseSelectionPlan):
                manifest["retained_release"] = plan.retained.val
            release = ReleaseId(self.git.prepare(manifest, plan.base.val if plan.base else None, artifacts))
            if self.fault is not None:
                self.fault("after_manifest_commit")
            journal["release"] = release.val
            self._phase(journal, "manifest")
        self.git.publish(release.val, plan.base.val if plan.base else None)
        if self.fault is not None:
            self.fault("after_publish_cas")
        self._phase(journal, "published")
        return {"outcome": "applied", "release": release.val, "plan": plan.id.val}

    def recover(self) -> JsonObject:
        results: list[JsonValue] = []
        with writer_lock(self.lock):
            for path in sorted((self.root / "journal").glob("*.json")):
                journal = load(path)
                plan = self._plan(PlanId(text(journal["id"], "id")))
                approval = Approval.decode(object_value(journal["approval"]))
                try:
                    results.append(self._finish(plan, approval, journal))
                except KctxError as exc:
                    results.append({"plan": plan.id.val, "outcome": "conflict", "error": str(exc)})
        return {"operations": results}

    def context(self, claims: tuple[ClaimRef, ...], context: Context, limit: int = 20, continuation: JsonObject | None = None, release: ReleaseId | None = None) -> JsonObject:
        if limit < 1 or limit > 100:
            raise KctxError("malformed", "context limit must be between 1 and 100")
        query = digest(canonical({"claims": [object_value(enc_ref(ref)) for ref in claims], "context": object_value(enc_context(context))}))
        offset = 0
        if continuation:
            if set(continuation) != {"release", "offset", "query"} or continuation["query"] != query:
                raise KctxError("conflict", "continuation belongs to another query/context")
            release = ReleaseId(text(continuation["release"], "release"))
            raw_offset = continuation["offset"]
            if type(raw_offset) is not int or raw_offset < 0:
                raise KctxError("malformed", "invalid continuation offset")
            offset = raw_offset
        release = release or self._current()
        if release is None:
            raise KctxError("not-found", "no completed knowledge release")
        self._require_completed(release)
        _, policy = self._policy(release)
        kb = self._base(release, policy)
        if context.snapshot != kb.snapshot:
            raise KctxError("conflict", "context snapshot does not match pinned release")
        if context.sources != self._sources(release):
            raise KctxError("conflict", "query source selections differ from the pinned completed release")
        wanted = set(claims)
        active = set(self._selected(release))
        selected = [claim for claim in kb.claims if claim.ref in active and (not wanted or claim.ref in wanted) and narrower(context.target, claim.statement.scope)]
        page = selected[offset:offset + limit]
        records: list[JsonValue] = []
        wire = object_value(enc_kb(kb))
        for claim in page:
            ref = object_value(enc_ref(claim.ref))
            opposite = [other for other in kb.claims if other.statement.formula == claim.statement.formula and other.statement.scope == claim.statement.scope and other.statement.polarity != claim.statement.polarity]
            relevant_refs = [ref] + [object_value(enc_ref(other.ref)) for other in opposite]
            records.append({"claim": {"id": claim.id.val, "revision": claim.revision.val, "statement": next(object_value(item)["statement"] for item in self._list(wire["claims"]) if object_value(item)["id"] == claim.id.val and object_value(item)["revision"] == claim.revision.val)}, "assessment": object_value(enc_assessment(assess(kb, context, claim.ref))), "contrary": [object_value(enc_ref(other.ref)) for other in opposite], "attestations": [item for item in self._list(wire["attestations"]) if object_value(item)["claim"] in relevant_refs], "derivations": [item for item in self._list(wire["derivations"]) if object_value(item)["claim"] in relevant_refs], "receipts": [item for item in self._list(wire["receipts"]) if object_value(item)["claim"] in relevant_refs]})
        end = offset + len(page)
        omitted = max(0, len(selected) - end)
        manifest = self.git.manifest(release.val)
        # Verify all pinned content before exposing assessments. Missing exact
        # source bytes is an explicit failure, never a HEAD/content fallback.
        for identity in self._list(manifest["artifacts"]):
            self._artifact(ContentDigest(text(identity, "artifact")), release)
        result: JsonObject = {"release": release.val, "snapshot": kb.snapshot.val, "records": records, "omitted": omitted, "complete": omitted == 0, "missing": [object_value(enc_ref(ref)) for ref in claims if find_claim(kb, ref) is None], "continuation": {"release": release.val, "offset": end, "query": query} if omitted else None, "provenance": {"manifest": manifest, "observations": wire["observations"]}, "evidence_omitted": False}
        result["scope_omitted"] = sum(1 for claim in kb.claims if (not wanted or claim.ref in wanted) and not narrower(context.target, claim.statement.scope))
        result["selection_omitted"] = sum(1 for claim in kb.claims if claim.ref not in active and (not wanted or claim.ref in wanted))
        result["not_selected"] = [object_value(enc_ref(ref)) for ref in claims if find_claim(kb, ref) is not None and ref not in active]
        result["provenance"] = {"manifest": manifest, "observations": wire["observations"], "corrections": wire["corrections"]}
        # The response has an explicit 64 KiB byte ceiling as well as a record
        # bound. Detailed evidence can be omitted, but this must be visible.
        if len(canonical(result)) > 65536:
            result["provenance"] = {"release": release.val, "dolt_commit": manifest["dolt_commit"], "policy": manifest["policy"], "plan_artifact": manifest["plan_artifact"], "approval_artifact": manifest["approval_artifact"]}
            for index, raw in enumerate(records):
                item = object_value(raw)
                for field in ("attestations", "derivations", "receipts", "contrary"):
                    item[field] = []
                records[index] = item
            result["evidence_omitted"] = True
            result["complete"] = False
        while len(canonical(result)) > 65536 and records:
            records.pop()
            end -= 1
            result["omitted"] = len(selected) - end
            result["continuation"] = {"release": release.val, "offset": end, "query": query}
            result["complete"] = False
        if len(canonical(result)) > 65536 or (page and not records):
            raise KctxError("incomplete", "single claim or query exceeds bounded context; narrow the exact query")
        return result

    @staticmethod
    def _list(value: JsonValue) -> list[JsonValue]:
        if not isinstance(value, list):
            raise KctxError("malformed", "expected record array")
        return value

    def explain(self, claim: ClaimRef, context: Context, release: ReleaseId | None = None) -> JsonObject:
        return self.context((claim,), context, 1, release=release)

    def backup(self, destination: Path) -> JsonObject:
        with writer_lock(self.lock):
            if destination.exists():
                raise KctxError("conflict", "backup destination already exists")
            release = self._current()
            if release is None:
                raise KctxError("not-found", "cannot back up an unpublished store")
            _, policy = self._policy(release)
            self._base(release, policy)
            destination.mkdir(parents=True)
            self.git.run("bundle", "create", str((destination / "authored.bundle").resolve()), "--all")
            authored_branch = self.git.run("symbolic-ref", "--quiet", "HEAD").strip()
            self.store.run("backup", "sync-url", (destination / "dolt").resolve().as_uri())
            shutil.copytree(self.root, destination / "operations")
            save(destination / "backup.json", {"schema_version": 2, "release": release.val, "policy": self.git.manifest(release.val)["policy"], "kb_id": policy["kb_id"], "authored_branch": authored_branch})
            return {"backup": str(destination), "release": release.val}


    def restore(self, source: Path) -> JsonObject:
        with writer_lock(self.lock):
            if self._current() is not None or self.store.path.exists():
                raise KctxError("conflict", "restore requires no published release and nonexistent Dolt destination")
            if self.git.run("for-each-ref", "--format=%(refname)", "refs/heads").strip():
                raise KctxError("conflict", "restore requires an empty authored repository")
            metadata = load(source / "backup.json")
            if metadata.get("schema_version") != 2:
                raise KctxError("malformed", "unsupported backup schema")
            release = ReleaseId(text(metadata["release"], "release"))
            self.git.run("fetch", str((source / "authored.bundle").resolve()), RELEASE_REF + ":refs/kctx/restore-candidate", "refs/heads/*:refs/heads/*", "refs/tags/*:refs/tags/*")
            restore_backup(source / "dolt", self.store.path, dolt_bin=self.store.binary)
            manifest = self.git.manifest(release.val)
            if manifest["policy"] != metadata["policy"] or manifest["kb_id"] != metadata["kb_id"]:
                raise KctxError("conflict", "backup metadata does not match pinned release")
            if self.bootstrap is None or self.bootstrap.val != manifest["policy"]:
                raise KctxError("conflict", "restore policy does not match configured trust anchor")
            _, policy = self._policy(release)
            kb = self._base(release, policy)
            if not well_formed(kb):
                raise KctxError("conflict", "restored generation violates semantic invariants")
            for artifact in self._list(manifest["artifacts"]):
                self._artifact(ContentDigest(text(artifact, "artifact")), release)
            shutil.copytree(source / "operations", self.root, dirs_exist_ok=True, ignore=shutil.ignore_patterns("writer.lock"))
            branch = text(metadata["authored_branch"], "authored_branch")
            heads = self.git.run("for-each-ref", "--format=%(refname)", "refs/heads").splitlines()
            if branch in heads:
                self.git.run("checkout", branch.removeprefix("refs/heads/"))
            self.git.publish(release.val, None)
            return {"outcome": "restored", "release": release.val}

    def _rollback_migration(self, identity: PlanId, receipt: JsonObject) -> JsonObject:
        receipt_path = self.root / "migrations" / identity.val / "receipt.json"
        if receipt.get("state") == "rolled_back":
            return receipt
        receipt["state"] = "rolling_back"
        save(receipt_path, receipt)
        durable_unlink(self.root / "migration-candidates" / (identity.val + ".json"))
        receipt["state"] = "rolled_back"
        save(receipt_path, receipt)
        return receipt

    def migrate(self, source: Path, apply: bool = False, rollback: PlanId | None = None) -> JsonObject:
        with writer_lock(self.lock):
            if rollback:
                receipt = load(self.root / "migrations" / rollback.val / "receipt.json")
                return self._rollback_migration(rollback, receipt)
            if source.is_dir():
                return self._migrate_legacy(source, apply)
            raw = source.read_bytes()
            try:
                envelope = decode(raw)
            except (ValueError, KctxError):
                return self._migrate_legacy(source, apply)
            if "candidate" not in envelope:
                return self._migrate_legacy(source, apply)
            identity = PlanId(digest(raw))
            directory = self.root / "migrations" / identity.val
            receipt_path = directory / "receipt.json"
            if receipt_path.exists():
                previous = load(receipt_path)
                if previous.get("state") == "rolling_back":
                    return self._rollback_migration(identity, previous)
                return previous
            accepted: JsonValue = None
            reason: str | None = None
            try:
                data = decode(raw)
                if data.get("schema_version") != 2 or data.get("semantic_version") != "2.0.0" or set(data) != {"schema_version", "semantic_version", "candidate"}:
                    raise ValueError("unknown or historical schema lacks exact source identities")
                candidate = object_value(data["candidate"])
                kb = dec_kb(candidate["kb"])
                if not well_formed(kb):
                    raise ValueError("candidate semantic invariants fail")
                if any(not observation.revision or not observation.content for observation in kb.observations):
                    raise ValueError("historical provenance is ambiguous")
                accepted = candidate
            except (ValueError, KeyError, KctxError) as exc:
                reason = str(exc)
            receipt: JsonObject = {"schema_version": 2, "migration": identity.val, "state": "dry_run" if not apply else "quarantined" if reason else "candidate", "accepted": 0 if reason else 1, "quarantined": 1 if reason else 0, "reason": reason, "restore_point": identity.val, "published": False}
            if apply:
                durable_write(directory / "source.bytes", raw)
                if accepted is not None:
                    save(self.root / "migration-candidates" / (identity.val + ".json"), object_value(accepted))
                # Receipt publication is the completed migration marker. Every
                # retained source and staged candidate is durable before it.
                save(receipt_path, receipt)
            return receipt

    def _migrate_legacy(self, source: Path, apply: bool) -> JsonObject:
        imported = inspect_legacy(source)
        directory = self.root / "migrations" / imported.id.val
        receipt_path = directory / "receipt.json"
        if receipt_path.exists():
            previous = load(receipt_path)
            if previous.get("state") == "rolling_back":
                return self._rollback_migration(imported.id, previous)
            return previous
        receipt = imported.report()
        receipt["state"] = "dry_run" if not apply else "candidate" if receipt["accepted"] else "quarantined"
        receipt["restore_point"] = imported.id.val
        receipt["source_kind"] = "legacy-authored"
        if not apply:
            return receipt
        self._policy(self._current())
        intent_path = directory / "intent.json"
        if intent_path.exists():
            observed_at = load(intent_path)["observed_at"]
            if type(observed_at) is not int:
                raise KctxError("malformed", "invalid migration capture timestamp")
        else:
            observed_at = int(time.time())
            save(intent_path, {"schema_version": 2, "migration": imported.id.val, "observed_at": observed_at})
        captures: list[JsonValue] = []
        source_root = source.resolve() if source.is_dir() else source.resolve().parent
        accepted_paths = {item.path: item for item in imported.items if item.kind != "citation" and item.disposition in (Disposition.EXACT, Disposition.UNIQUE)}
        for retained in imported.files:
            durable_write(safe_restore_path(directory / "restore", retained.path), retained.data)
            item = accepted_paths.get(retained.path)
            if item is not None:
                capture = self._capture_bytes(CaptureKind.DOCUMENT if item.kind == "document" else CaptureKind.SOURCE, (source_root / retained.path).as_uri(), "content:sha256:" + digest(retained.data), retained.data, observed_at)
                captures.append({"path": retained.path, "authored_id": item.authored_id, "capture": capture.wire(), "historical_revision": None})
        for retained in imported.resolved_sources:
            capture = self._capture_bytes(CaptureKind.SOURCE, retained.path, retained.path.rsplit("#", 1)[1].split(":", 1)[0], retained.data, observed_at)
            captures.append({"path": retained.path, "authored_id": None, "capture": capture.wire(), "historical_revision": capture.revision})
        candidate: JsonObject = {"schema_version": 2, "kind": "legacy-source-candidates", "migration": imported.id.val, "captures": captures, "claims": [], "items": receipt["items"], "requires_structured_proposal": True}
        save(self.root / "migration-candidates" / (imported.id.val + ".json"), candidate)
        receipt["captures"] = captures
        save(receipt_path, receipt)
        return receipt

    def restore_migration(self, identity: PlanId, destination: Path) -> JsonObject:
        with writer_lock(self.lock):
            if destination.exists():
                raise KctxError("conflict", "migration restore requires a new destination")
            directory = self.root / "migrations" / identity.val
            receipt = load(directory / "receipt.json")
            entries = receipt.get("files")
            restored: list[JsonValue] = []
            if isinstance(entries, list):
                for raw in entries:
                    entry = object_value(raw)
                    relative = text(entry["path"], "path")
                    data = safe_restore_path(directory / "restore", relative).read_bytes()
                    if digest(data) != entry["content"]:
                        raise KctxError("conflict", "retained migration restore-point digest mismatch")
                    durable_write(safe_restore_path(destination, relative), data)
                    restored.append({"path": relative, "content": digest(data)})
            else:
                data = (directory / "source.bytes").read_bytes()
                if digest(data) != identity.val:
                    raise KctxError("conflict", "retained export restore-point digest mismatch")
                durable_write(destination / "source.json", data)
                restored.append({"path": "source.json", "content": digest(data)})
            result: JsonObject = {"schema_version": 2, "migration": identity.val, "destination": str(destination), "restored": restored, "published": False}
            save(directory / "restore-receipt.json", result)
            return result
