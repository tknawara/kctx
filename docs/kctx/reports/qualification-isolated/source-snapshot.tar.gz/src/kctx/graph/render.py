"""Compact human-readable graph/log output over checked JSON wire values."""

import argparse

from kctx.domain.json import JsonObject, JsonValue, integer, json_value, text
from kctx.errors import KctxError
from kctx.observability import format_event_line


def _short(node: str, width: int = 110) -> str:
    return node if len(node) <= width else node[: width - 1] + "…"


def _record(value: JsonValue) -> JsonObject:
    if not isinstance(value, dict):
        raise KctxError("malformed", "graph output requires an object")
    return value


def _rows(value: JsonValue) -> list[JsonValue]:
    if not isinstance(value, list):
        raise KctxError("malformed", "graph output requires an array")
    return value


def render_graph_text(args: argparse.Namespace, result: object) -> None:
    wire = json_value(result, "graph output")
    if args.command == "logs":
        events = _rows(wire)
        if not events:
            print("(no events)")
        for event in events:
            print(format_event_line(_record(event)))
        return

    data = _record(wire)
    cmd = args.graph_command
    if cmd == "sync":
        extra = f", {data['commits_replayed']} commit(s) replayed" if "commits_replayed" in data else ""
        sha = text(data["kb_sha"], "kb_sha")[:10]
        print(f"{data['status']}: kb {sha} -> dolt {data['dolt_commit']} "
              f"({data['node_count']} nodes, {data['edge_count']} edges{extra})")
    elif cmd == "status":
        if not data["initialized"]:
            print(f"graph not initialized at {data['graph_dir']}; run `kctx graph sync`")
            return
        st = _record(data["sync_state"] or {})
        state = "current" if data["up_to_date"] else f"STALE (kb HEAD {text(data['kb_head'], 'kb_head')[:10]})"
        print(f"graph {data['graph_dir']}")
        print(f"synced kb {str(st.get('kb_sha'))[:10]} at {st.get('synced_at')} -- {state}")
        print(f"{data['node_count']} nodes, {data['edge_count']} edges")
    elif cmd == "uses":
        truncated = integer(data["returned"], "returned") < integer(data["total"], "total")
        print(f"{data['target']}: {data['total']} inbound edge(s)"
              + (f" (showing {data['returned']})" if truncated else ""))
        for rel, value in _record(data["by_rel"]).items():
            rows = _rows(value)
            print(f"  {rel} ({len(rows)})")
            for value in rows:
                row = _record(value)
                print(f"    [{row.get('src_kind') or '?'}] {_short(text(row['src_node'], 'src_node'))}")
    elif cmd == "impact":
        truncated = integer(data["returned"], "returned") < integer(data["total"], "total")
        print(f"{data['target']}: {data['total']} dependent(s) within depth {data['depth']}"
              + (f" (showing {data['returned']})" if truncated else ""))
        for value in _rows(data["dependents"]):
            row = _record(value)
            print(f"  d{row['depth']} [{row.get('kind') or '?'}] {_short(text(row['node'], 'node'))}")
    elif cmd == "diff":
        print(f"{data['kb_sha_a']} -> {data['kb_sha_b']}")
        for value in _rows(data["summary"]):
            row = _record(value)
            print(f"  {text(row['rel'], 'rel'):<22} {text(row['diff_type'], 'diff_type'):<9} {row['n']}")
    elif cmd == "check":
        parity = _record(data["parity"])
        verdict = "MATCH" if parity["match"] else "MISMATCH"
        print(f"parity {verdict} at kb {text(parity['kb_sha'], 'kb_sha')[:10]}: {parity['direct_cite_tokens']} cite tokens parsed directly = "
              f"{parity['graph_binding_rows']} binding rows + {parity['skipped_tokens']} skipped "
              f"(illus {parity['direct_illus_tokens']} direct / {parity['graph_illus_rows']} in graph)")
        print(f"  exact bindings: {parity['binding_mismatch_count']} mismatch(es); "
              f"inputs {'current' if parity['inputs_match'] else 'STALE'}; "
              f"{parity['diagnostic_count']} extraction diagnostic(s)")
        for value in _rows(parity["skips"]):
            skip = _record(value)
            print(f"  skip {skip['src_path']}:{skip['line']} {skip['reason']}")
        for value in _rows(parity["binding_mismatches"]):
            mismatch = _record(value)
            expected = _record(mismatch["expected"] or {})
            actual = _record(mismatch["actual"] or {})
            print(f"  BINDING {mismatch['edge_id']}: "
                  f"{expected.get('src_path') or actual.get('src_path')}:"
                  f"{expected.get('src_line') or actual.get('src_line')}")
            for field in sorted(expected.keys() | actual.keys()):
                if expected.get(field) != actual.get(field):
                    print(f"    {field}: expected={_short(repr(expected.get(field)))} "
                          f"actual={_short(repr(actual.get(field)))}")
        if parity["diagnostics_truncated"]:
            print("  extraction diagnostic samples truncated; full records retained in the generation")
        for value in _rows(data["uses_comparison"]):
            comparison = _record(value)
            print(f"uses {comparison['target']}: graph {comparison['graph_total']} vs `kctx uses` {comparison['file_total']}")
            for value in _rows(comparison["graph_only"]):
                print(f"  graph-only {value}")
            for value in _rows(comparison["file_only"]):
                print(f"  file-only  {value}")
    else:
        print(data)
