"""Consumer regressions for untrusted policy, query, journal and backup inputs."""
from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path
import unittest
from unittest.mock import patch

import test_knowledge as fixtures
from kctx.adapters.files.knowledge import digest, canonical, load, save
from kctx.cli.arguments import Arguments
from kctx.cli import knowledge as knowledge_cli
from kctx.config import Config
from kctx.domain.ids import AuthorityKeyId, DoltCommitId, PolicyDigest, ReleaseId, SourceId, SourceRevision
from kctx.domain.json import JsonObject, object_value, text
from kctx.errors import KctxError
from kctx.semantics.wire import enc_context, enc_kb, enc_ref, enc_witness
from kctx.services.knowledge import KnowledgeEngine
from kctx.services.knowledge_models import AdmissionPlan, Approval, CaptureKind


class SimulatedStop(RuntimeError):
    pass


class KnowledgeBoundaryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.fixture = fixtures.KnowledgeAdmissionTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.engine = self.fixture.engine
        self.key = AuthorityKeyId("reviewer-key")

    def plan(self, snapshot: str = "generation-1") -> tuple[AdmissionPlan, Approval]:
        candidate = self.fixture.candidate(CaptureKind.DOCUMENT)
        kb = object_value(candidate["kb"])
        kb["snapshot"] = snapshot
        candidate["kb"] = kb
        plan = self.engine.propose(candidate, "review", 5)
        return plan, self.engine.sign(plan.id, self.fixture.key_file, self.key)

    def published(self) -> tuple[AdmissionPlan, Approval, ReleaseId]:
        plan, approval = self.plan()
        reply = self.engine.admit(plan.id, approval)
        return plan, approval, ReleaseId(text(reply["release"], "release"))

    def next_plan(self, previous: AdmissionPlan, snapshot: str) -> tuple[AdmissionPlan, Approval]:
        kb = object_value(enc_kb(previous.semantic.candidate))
        kb["snapshot"] = snapshot
        context = replace(previous.context, snapshot=previous.semantic.candidate.snapshot, now=6)
        candidate: JsonObject = {"kb": kb, "capture_ids": [identity.val for identity in previous.captures], "context": object_value(enc_context(context)), "claim": object_value(enc_ref(previous.semantic.claim)), "witness": object_value(enc_witness(previous.semantic.witness)), "authority_key": self.key.val}
        plan = self.engine.propose(candidate, "review", 6)
        return plan, self.engine.sign(plan.id, self.fixture.key_file, self.key)

    def interrupt(self, plan: AdmissionPlan, approval: Approval, phase: str) -> JsonObject:
        def stop(current: str) -> None:
            if current == phase:
                raise SimulatedStop(current)
        self.engine.fault = stop
        try:
            with self.assertRaises(SimulatedStop):
                self.engine.admit(plan.id, approval)
        finally:
            self.engine.fault = None
        return load(self.engine.root / "journal" / (plan.id.val + ".json"))

    def test_boundary_strict_nested_policy_codec(self) -> None:
        original = load(self.fixture.repo / ".kctx" / "knowledge-policy.json")
        original_key = object_value(object_value(original["trusted_keys"])[self.key.val])
        variants: list[JsonObject] = [
            {**original, "schema_version": 2.0},
            {**original, "trusted_keys": {self.key.val: {**original_key, "public_key": "zz"}}},
            {**original, "trusted_keys": {self.key.val: {**original_key, "target_uses": ["review", 17]}}},
            {**original, "trusted_keys": {self.key.val: original_key, "unused": {"public_key": original_key["public_key"]}}},
            {**original, "trusted_keys": {self.key.val: original_key, "unused": {**original_key, "revoked": True}}},
        ]
        for policy in variants:
            with self.subTest(policy=policy):
                save(self.fixture.repo / ".kctx" / "knowledge-policy.json", policy)
                self.engine.bootstrap = PolicyDigest(digest(canonical(policy)))
                with self.assertRaises(KctxError):
                    self.engine.capture(CaptureKind.DOCUMENT, SourceId("doc"), SourceRevision("r1"), b"bytes", 1)

    def test_boundary_approval_and_semantic_decode_errors_are_domain_errors(self) -> None:
        plan, approval = self.plan()
        for record in ({**approval.wire(), "signature": "zz"}, {**approval.wire(), "signature": "ab" * 63}, {**approval.wire(), "accepted": True}, {**approval.wire(), "schema_version": 2.0}):
            with self.subTest(record=record), self.assertRaises(KctxError):
                Approval.decode(record)
        candidate = self.fixture.candidate(CaptureKind.DOCUMENT)
        candidate["context"] = {"unknown": True}
        path = self.fixture.root / "bad-candidate.json"
        save(path, candidate)
        config = Config(knowledge_dir=self.engine.store.path, knowledge_policy_digest=plan.policy.val)
        args = Arguments(argparse.Namespace(knowledge_command="propose", candidate=str(path), target_use="review", now=5))
        with patch.object(Config, "load", return_value=config), self.assertRaises(KctxError):
            knowledge_cli.dispatch(args, self.fixture.repo)

    def test_boundary_unsigned_query_cannot_weaken_approved_context(self) -> None:
        plan, _, _ = self.published()
        context = replace(plan.context, snapshot=plan.semantic.candidate.snapshot)
        variants = (
            replace(context, intended_use="production-deploy"),
            replace(context, policy=replace(context.policy, require_fresh=False)),
            replace(context, policy=replace(context.policy, require_validation=True)),
            replace(context, now=context.now - 1),
            replace(context, checker=type(context.checker)("other-checker")),
        )
        for changed in variants:
            with self.subTest(context=changed), self.assertRaises(KctxError):
                self.engine.context((plan.semantic.claim,), changed)

    def test_boundary_foreign_signed_journal_release_is_not_authority(self) -> None:
        first, approval = self.plan("candidate-a")
        journal = self.interrupt(first, approval, "prepared")
        foreign, foreign_approval = self.plan("candidate-b")
        foreign_journal = self.interrupt(foreign, foreign_approval, "manifest")
        journal["release"] = foreign_journal["release"]
        save(self.engine.root / "journal" / (first.id.val + ".json"), journal)
        with self.assertRaises(KctxError):
            self.engine.admit(first.id, approval)
        self.assertIsNone(self.engine.git.current())

    def test_boundary_current_release_cannot_fake_other_operation_replay(self) -> None:
        first, _, release = self.published()
        second, approval = self.next_plan(first, "generation-2")
        journal = self.interrupt(second, approval, "prepared")
        journal["release"] = release.val
        save(self.engine.root / "journal" / (second.id.val + ".json"), journal)
        with self.assertRaises(KctxError):
            self.engine.admit(second.id, approval)
        self.assertEqual(self.engine.git.current(), release.val)

    def test_boundary_native_admission_rows_are_validated(self) -> None:
        plan, approval = self.plan()
        journal = self.interrupt(plan, approval, "candidate")
        self.engine.store.execute("UPDATE admissions SET actor = 'foreign-signer'")
        self.engine.store.run("add", ".")
        self.engine.store.run("commit", "--author", "fixture <fixture@localhost>", "-m", "Corrupt admission metadata only")
        changed = DoltCommitId(text(self.engine.store.sql("SELECT DOLT_HASHOF('HEAD') AS h")[0]["h"], "hash"))
        journal["dolt_commit"] = changed.val
        save(self.engine.root / "journal" / (plan.id.val + ".json"), journal)
        with self.assertRaises(KctxError):
            self.engine.admit(plan.id, approval)
        self.assertIsNone(self.engine.git.current())

    def test_boundary_configured_dolt_binary_is_not_ignored(self) -> None:
        missing = self.fixture.root / "missing-configured-dolt"
        with patch.object(Config, "load", return_value=Config(dolt_bin=missing)), self.assertRaises(KctxError):
            KnowledgeEngine(self.fixture.repo, self.fixture.root / "other-store", self.engine.bootstrap)

    def test_boundary_corrupt_backup_cannot_select_unpublished_manifest(self) -> None:
        first, _, release = self.published()
        pending, approval = self.next_plan(first, "generation-2")
        journal = self.interrupt(pending, approval, "manifest")
        pending_release = text(journal["release"], "release")
        self.engine.git.run("update-ref", "refs/kctx/retained-pending-fixture", pending_release)
        backup = self.fixture.root / "backup"
        self.engine.backup(backup)
        metadata = load(backup / "backup.json")
        metadata["release"] = pending_release
        save(backup / "backup.json", metadata)
        restored_repo = self.fixture.root / "restored-authored"
        restored_repo.mkdir()
        self.engine.git.run("init", "-q", str(restored_repo))
        restored = KnowledgeEngine(restored_repo, self.fixture.root / "restored-dolt", self.engine.bootstrap)
        with self.assertRaises(KctxError):
            restored.restore(backup)
        self.assertIsNone(restored.git.current())
        self.assertEqual(self.engine.git.current(), release.val)


if __name__ == "__main__":
    unittest.main()
