"""Inventory commands: decode identifiers and vocabulary at the CLI edge."""

from pathlib import Path

from kctx.cli.arguments import Arguments
from kctx.cli.result import Reply
from kctx.codecs.records import encode_asset, encode_impact, encode_relationship
from kctx.domain.ids import AssetId, EvidenceId, RelationshipId
from kctx.domain.vocabulary import AssetKind, Lifecycle, RelationshipStatus, RelationshipType
from kctx.errors import KctxError
from kctx.services import inventory


def dispatch(args: Arguments, root: Path) -> Reply:
    command = args.text("command")
    if command == "impact":
        return Reply(
            encode_impact(inventory.impact(root, args.text("asset"), depth=args.integer("depth")))
        )
    if command == "rel":
        relationship = inventory.rel_add(
            root,
            type=args.parsed("type", RelationshipType),
            from_=args.parsed("from_", AssetId),
            to=args.parsed("to", AssetId),
            id=args.optional_parsed("id", RelationshipId),
            status=args.parsed("status", RelationshipStatus),
            evidence=args.many("evidence", EvidenceId),
            applicability=args.text("applicability"),
        )
        return Reply(encode_relationship(relationship))
    action = args.text("asset_command")
    if action == "show":
        return Reply(encode_asset(inventory.asset_show(root, args.text("ident"))))
    if action == "list":
        assets = inventory.asset_list(
            root, kind=args.optional_parsed("kind", AssetKind), project=args.optional("project")
        )
        return Reply([encode_asset(asset) for asset in assets])
    if action == "add":
        asset = inventory.asset_add(
            root,
            kind=args.parsed("kind", AssetKind),
            name=args.text("name"),
            id=args.optional_parsed("id", AssetId),
            aliases=args.strings("aliases"),
            locator=args.text("locator"),
            owner=args.text("owner"),
            owner_source=args.text("owner_source"),
            lifecycle=args.parsed("lifecycle", Lifecycle),
            inspect=args.text("inspect"),
            projects=args.strings("projects"),
            verified_at=args.optional("verified_at"),
            ttl=args.optional("ttl"),
            notes=args.text("notes"),
        )
        return Reply(encode_asset(asset))
    raise KctxError("malformed", f"unhandled asset command {action!r}")
