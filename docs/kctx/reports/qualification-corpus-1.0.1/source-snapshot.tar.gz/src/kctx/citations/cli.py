"""Built-in cite make/check/stale/render command family."""

import argparse
import json
import sys
from collections.abc import Sequence

from kctx.citations.code import make_code
from kctx.citations.construction import make_other, make_proposal
from kctx.citations.rendering import extract_cite_items, render_one
from kctx.citations.scan import check_to_wire, run_check, run_stale, stale_to_wire
from kctx.cli.arguments import Arguments
from kctx.domain.json import JsonObject, JsonValue, integer, object_value, text
from kctx.errors import KctxError


def register(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true", default=argparse.SUPPRESS)
    sub = parser.add_subparsers(dest="cite_command", required=True)
    make = sub.add_parser("make")
    make.add_argument("kind")
    make.add_argument("rest", nargs=argparse.REMAINDER)
    check = sub.add_parser("check")
    check.add_argument("paths", nargs="*")
    check.add_argument("--line")
    check.add_argument("--touch", action="store_true")
    check.add_argument("--touch-all", action="store_true")
    check.add_argument("--mark", action="store_true")
    stale = sub.add_parser("stale")
    stale.add_argument("paths", nargs="*")
    stale.add_argument("--offline", action="store_true")
    render = sub.add_parser("render")
    render.add_argument("target")
    render.add_argument("--format", choices=("md", "slack", "plain"), default="plain")
    render.add_argument("--audience", choices=("internal", "tl", "external"), default="internal")
    render.add_argument("--unredacted", action="store_true")
    render.add_argument("--check", action="store_true")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="kctx cite")
    register(parser)
    return parser


def _code_arguments(tokens: Sequence[str]) -> Arguments:
    parser = argparse.ArgumentParser(prog="kctx cite make code")
    parser.add_argument("repo")
    parser.add_argument("path")
    parser.add_argument("range")
    parser.add_argument("--sym")
    parser.add_argument("--rev")
    parser.add_argument("--ttl", default="14d")
    parser.add_argument("--allow-dirty", action="store_true")
    parser.add_argument("--sens")
    parser.add_argument("--redact")
    return Arguments(parser.parse_args(tokens))


def _parse_fields(tokens: Sequence[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for token in tokens:
        if "=" not in token:
            raise KctxError("malformed", f"expected key=value, got {token!r}")
        key, value = token.split("=", 1)
        result[key] = value
    return result


def dispatch(args: Arguments) -> tuple[JsonObject, int]:
    command = args.text("cite_command")
    if command == "make":
        kind = args.text("kind")
        if kind == "code":
            code = _code_arguments(args.strings("rest"))
            made = make_code(
                code.text("repo"),
                code.text("path"),
                code.text("range"),
                sym=code.optional("sym"),
                rev=code.optional("rev"),
                ttl=code.text("ttl"),
                allow_dirty=code.flag("allow_dirty"),
                sens=code.optional("sens"),
                redact=code.optional("redact"),
            )
        else:
            fields = _parse_fields(args.strings("rest"))
            if kind == "proposal":
                if "id" not in fields:
                    raise KctxError("incomplete", "kind=proposal requires id=")
                made = make_proposal(fields["id"], ttl=fields.get("ttl"))
            else:
                made = make_other(kind, fields)
        return made.to_wire(), 0
    if command == "check":
        checked = run_check(
            args.strings("paths"),
            inline_line=args.optional("line"),
            touch=args.flag("touch"),
            touch_all=args.flag("touch_all"),
            mark=args.flag("mark"),
        )
        return check_to_wire(checked), checked["exit_code"]
    if command == "stale":
        stale = run_stale(args.strings("paths"), offline=args.flag("offline"))
        return stale_to_wire(stale), stale["exit_code"]
    if command == "render":
        rendered: list[JsonValue] = [
            render_one(
                fields,
                fmt=args.text("format"),
                audience=args.text("audience"),
                unredacted=args.flag("unredacted"),
                do_check=args.flag("check"),
            )
            for fields, _raw in extract_cite_items(args.text("target"))
        ]
        return {"rendered": rendered}, 0
    raise KctxError("malformed", f"unhandled citation command {command!r}")


def _rows(result: JsonObject, name: str) -> list[JsonValue]:
    value = result.get(name)
    if not isinstance(value, list):
        raise KctxError("malformed", f"{name} must be an array")
    return value


def render_text(result: JsonObject, command: str) -> None:
    if command == "make":
        print(text(result.get("line"), "line"))
    elif command == "check":
        rows = _rows(result, "results")
        warnings = _rows(result, "warnings")
        skipped = _rows(result, "skipped")
        for value in rows:
            row = object_value(value)
            status = text(row.get("status"), "status")
            location = f"{row['file']}:{row['line_no']}" if row.get("file") else "(--line)"
            print(f"{status:12} {location}")
            if status == "moved":
                print(f"             new L={row.get('L')}")
            elif status == "changed" and row.get("sym_line"):
                print(f"             symbol now near line {row['sym_line']}")
            elif status == "gone":
                print(f"             head={row.get('head')}")
            elif status == "unverifiable":
                print(f"             reason={row.get('reason')}")
            if row.get("touched_line"):
                print(f"             touched: {row['touched_line']}")
        for value in warnings:
            warning = object_value(value)
            print(
                f"warn         {warning['file']}:{warning['line_no']} unpinned locator: {warning['text']}"
            )
        print(
            f"-- {len(rows)} citation(s), {len(warnings)} warning(s), {len(skipped)} illus skipped, exit={result['exit_code']}"
        )
    elif command == "stale":
        if not _rows(result, "entries"):
            print("no stale/due citations")
        else:
            groups = object_value(result.get("groups"))
            for name in sorted(groups):
                group = object_value(groups[name])
                age = group.get("oldest_age_days")
                if not isinstance(age, (int, float)):
                    raise KctxError("malformed", "oldest_age_days must be numeric")
                print(
                    f"{name}: {integer(group.get('count'), 'count')} stale/due, oldest {age:.1f}d"
                )
            oldest = result.get("oldest_age_days")
            if not isinstance(oldest, (int, float)):
                raise KctxError("malformed", "oldest_age_days must be numeric")
            print(f"-- {result['total']} total, oldest {oldest:.1f}d, exit={result['exit_code']}")
    elif command == "render":
        for index, value in enumerate(_rows(result, "rendered")):
            if index:
                print()
            print(text(value, "rendered citation"))


def main(argv: Sequence[str] | None = None) -> int:
    args = Arguments(build_parser().parse_args(argv))
    try:
        result, code = dispatch(args)
    except KctxError as error:
        if args.flag("json"):
            print(json.dumps({"error": error.category, "message": error.message}))
        else:
            print(f"error ({error.category}): {error.message}", file=sys.stderr)
        return 1
    if args.flag("json"):
        print(json.dumps(result, indent=2))
    else:
        render_text(result, args.text("cite_command"))
    return code
