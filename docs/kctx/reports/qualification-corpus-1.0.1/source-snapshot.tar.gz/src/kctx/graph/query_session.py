"""Pinned, read-only graph sessions shared by Python and JSONL clients.

Protocol version 1: one ready envelope, then one response per input line.
Requests carry schema_version, id, op, and optional args. Only status, uses,
source-paths, impact and diff are accepted. A session never follows a new publication.
"""

import json
import signal
import subprocess
from contextlib import ExitStack
from pathlib import Path
from time import perf_counter
from types import FrameType, TracebackType
from typing import BinaryIO, TextIO

from kctx.adapters.dolt.read_session import DoltReadSession
from kctx.domain.json import JsonObject, JsonValue, fields, integer, text, texts
from kctx.errors import KctxError
from kctx.graph import queries
from kctx.graph.dolt_store import DoltStore
from kctx.graph.models import GraphNodeId
from kctx.graph.operations import active_db_dir, graph_home
from kctx.graph.sync import dolt_db_dir

MAX_REQUEST_BYTES = 65536


class QuerySession:
    """Explicit managed session; open/close costs are not query latency.

    The selected immutable publication and native data/metadata commits remain
    fixed until close. Methods use the ordinary graph query implementations.
    This object is single-client, sequential, and not thread-safe.
    """

    def __init__(self, kb_root: Path, *, store: DoltStore | None = None) -> None:
        self.kb_root = kb_root
        self._store = store
        self._stack = ExitStack()
        self._context: queries.QueryContext | None = None
        self._reader: DoltReadSession | None = None
        self._home: Path | None = None
        self.startup_ms = 0.0

    def __enter__(self) -> "QuerySession":
        if self._context is not None:
            raise KctxError("conflict", "query session is already open")
        started = perf_counter()
        store = self._store if self._store is not None else DoltStore(dolt_db_dir())
        snapshot = queries.select_snapshot(store, self.kb_root)
        home = graph_home(store)
        if store.db_dir == home / "dolt":
            raise KctxError(
                "conflict",
                "query sessions require an immutable published generation; run graph sync",
            )
        try:
            reader = self._stack.enter_context(store.read_session())
            self._reader = reader
            self._context = queries.QueryContext(reader, snapshot, store.db_dir)
            self._home = home
            self.startup_ms = (perf_counter() - started) * 1000
            return self
        except BaseException:
            self.close()
            raise

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        self._context = None
        self._home = None
        self._stack.close()

    @property
    def context(self) -> queries.QueryContext:
        if self._context is None:
            raise KctxError("conflict", "query session is not open")
        return self._context

    def resource_identity(self) -> JsonObject:
        """Expose native ownership for out-of-band measurement, not query timing."""
        if self._reader is None:
            raise KctxError("conflict", "query session has not been opened")
        return self._reader.resource_identity()

    def identity(self) -> JsonObject:
        context = self.context
        snapshot = context.snapshot
        home = self._home
        if home is None:
            raise KctxError("conflict", "query session is not open")
        return {
            "selection": "pinned",
            "graph_dir": str(context.db_dir),
            "metadata_commit": snapshot.metadata_commit.val,
            "data_commit": snapshot.data_commit.val,
            "kb_sha": snapshot.state.kb_sha,
            "input_digest": snapshot.state.input_digest,
            "is_current_publication": active_db_dir(home) == context.db_dir,
        }

    def status(self) -> JsonObject:
        return queries.status(self.kb_root, context=self.context)

    def uses(
        self, target: GraphNodeId, *, limit: int = 50, include_illus: bool = False
    ) -> JsonObject:
        return queries.uses(
            target,
            kb_root=self.kb_root,
            limit=limit,
            include_illus=include_illus,
            context=self.context,
        )

    def impact(
        self, target: GraphNodeId, *, depth: int = 3, rel: list[str] | None = None, limit: int = 100
    ) -> JsonObject:
        return queries.impact(
            target, kb_root=self.kb_root, depth=depth, rel=rel, limit=limit, context=self.context
        )

    def diff(self, kb_sha_a: str, kb_sha_b: str, *, limit: int = 200) -> JsonObject:
        return queries.diff(
            kb_sha_a, kb_sha_b, kb_root=self.kb_root, limit=limit, context=self.context
        )

    def source_paths(
        self, target: GraphNodeId, *, revision: str = "HEAD", limit: int = 1000
    ) -> JsonObject:
        return queries.source_paths(
            target, kb_root=self.kb_root, revision=revision, limit=limit, context=self.context
        )

    def request(self, value: object) -> JsonObject:
        request_id: JsonValue = None
        try:
            request = fields(value, required={"schema_version", "id", "op"}, optional={"args"})
            request_id = request["id"]
            if type(request_id) not in (str, int):
                request_id = None
                raise KctxError("malformed", "request id must be a string or integer")
            op = text(request["op"], "op")
            raw_args = request.get("args", {})
            if op == "status":
                fields(raw_args, required=set(), versioned=False)
                result = self.status()
            elif op == "uses":
                args = fields(
                    raw_args,
                    required={"target"},
                    optional={"limit", "include_illus"},
                    versioned=False,
                )
                include_illus = args.get("include_illus", False)
                if not isinstance(include_illus, bool):
                    raise KctxError("malformed", "include_illus must be a boolean")
                result = self.uses(
                    GraphNodeId(text(args["target"], "target")),
                    limit=integer(args.get("limit", 50), "limit"),
                    include_illus=include_illus,
                )
            elif op == "impact":
                args = fields(
                    raw_args,
                    required={"target"},
                    optional={"limit", "depth", "rel"},
                    versioned=False,
                )
                relations = None if "rel" not in args else list(texts(args["rel"], "rel"))
                result = self.impact(
                    GraphNodeId(text(args["target"], "target")),
                    limit=integer(args.get("limit", 100), "limit"),
                    depth=integer(args.get("depth", 3), "depth"),
                    rel=relations,
                )
            elif op == "source-paths":
                args = fields(
                    raw_args, required={"target"}, optional={"revision", "limit"}, versioned=False
                )
                result = self.source_paths(
                    GraphNodeId(text(args["target"], "target")),
                    revision=text(args.get("revision", "HEAD"), "revision"),
                    limit=integer(args.get("limit", 1000), "limit"),
                )
            elif op == "diff":
                args = fields(
                    raw_args, required={"kb_sha_a", "kb_sha_b"}, optional={"limit"}, versioned=False
                )
                result = self.diff(
                    text(args["kb_sha_a"], "kb_sha_a"),
                    text(args["kb_sha_b"], "kb_sha_b"),
                    limit=integer(args.get("limit", 200), "limit"),
                )
            else:
                raise KctxError("malformed", f"unsupported read-only operation: {op!r}")
            return {
                "schema_version": 1,
                "id": request_id,
                "ok": True,
                "generation": self.identity(),
                "result": result,
            }
        except KctxError as exc:
            return _error(exc, request_id)
        except ValueError as exc:
            return _error(KctxError("malformed", str(exc)), request_id)
        except (OSError, subprocess.SubprocessError) as exc:
            return _error(KctxError("incomplete", f"query failed: {exc}"), request_id)


def _error(exc: KctxError, request_id: JsonValue = None) -> JsonObject:
    return {
        "schema_version": 1,
        "id": request_id,
        "ok": False,
        "error": {"category": exc.category, "message": exc.message},
    }


def _emit(output: TextIO, value: JsonObject) -> None:
    output.write(json.dumps(value, separators=(",", ":"), allow_nan=False) + "\n")
    output.flush()


def _cancel(_signum: int, _frame: FrameType | None) -> None:
    raise KeyboardInterrupt


def serve(kb_root: Path, source: BinaryIO, output: TextIO) -> int:
    """Run bounded JSONL framing, cleaning the native child on EOF or signals."""
    previous = signal.signal(signal.SIGTERM, _cancel)
    try:
        with QuerySession(kb_root) as session:
            _emit(
                output,
                {
                    "schema_version": 1,
                    "event": "ready",
                    "ok": True,
                    "generation": session.identity(),
                    "startup_ms": session.startup_ms,
                    "max_request_bytes": MAX_REQUEST_BYTES,
                },
            )
            while True:
                line = source.readline(MAX_REQUEST_BYTES + 1)
                if not line:
                    return 0
                if len(line) > MAX_REQUEST_BYTES:
                    while line and not line.endswith(b"\n"):
                        line = source.readline(MAX_REQUEST_BYTES + 1)
                    _emit(output, _error(KctxError("malformed", "request exceeds 65536 bytes")))
                    continue
                try:
                    value: object = json.loads(line)
                    response = session.request(value)
                except (ValueError, UnicodeError, RecursionError) as exc:
                    response = _error(KctxError("malformed", f"invalid JSON request: {exc}"))
                _emit(output, response)
    except KctxError as exc:
        _emit(output, _error(exc))
        return 1
    except (KeyboardInterrupt, BrokenPipeError):
        return 130
    except (OSError, subprocess.SubprocessError) as exc:
        _emit(output, _error(KctxError("incomplete", f"query session failed: {exc}")))
        return 1
    finally:
        signal.signal(signal.SIGTERM, previous)
