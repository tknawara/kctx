"""Narrow argparse's dynamic namespace before entering typed services."""

import argparse
from collections.abc import Callable, Mapping
from typing import TypeVar, cast

from kctx.errors import KctxError

T = TypeVar("T")


class Arguments:
    def __init__(self, namespace: argparse.Namespace) -> None:
        self.namespace = namespace
        self._values = cast(Mapping[str, object], vars(namespace))

    def optional(self, name: str) -> str | None:
        value = self._values.get(name)
        if value is None or isinstance(value, str):
            return value
        raise KctxError("malformed", f"expected text for {name}")

    def text(self, name: str) -> str:
        value = self.optional(name)
        if value is None:
            raise KctxError("incomplete", f"missing {name}")
        return value

    def strings(self, name: str) -> tuple[str, ...]:
        value = self._values.get(name)
        if value is None:
            return ()
        if isinstance(value, list):
            values = cast(list[object], value)
            if all(isinstance(item, str) for item in values):
                return tuple(cast(str, item) for item in values)
        raise KctxError("malformed", f"expected a list of text for {name}")

    def flag(self, name: str) -> bool:
        value = self._values.get(name, False)
        if isinstance(value, bool):
            return value
        raise KctxError("malformed", f"expected a flag for {name}")

    def integer(self, name: str) -> int:
        value = self._values.get(name)
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        raise KctxError("malformed", f"expected an integer for {name}")

    def parsed(self, name: str, decode: Callable[[str], T]) -> T:
        return parse_value(name, self.text(name), decode)

    def optional_parsed(self, name: str, decode: Callable[[str], T]) -> T | None:
        value = self.optional(name)
        return None if value is None else parse_value(name, value, decode)

    def many(self, name: str, decode: Callable[[str], T]) -> tuple[T, ...]:
        return tuple(parse_value(name, value, decode) for value in self.strings(name))


def parse_value(name: str, value: str, decode: Callable[[str], T]) -> T:
    try:
        return decode(value)
    except ValueError as exc:
        raise KctxError("malformed", f"invalid {name}: {value!r}: {exc}") from exc
