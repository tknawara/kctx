"""Render encoded replies without leaking nominal records into the wire format."""

from collections.abc import Mapping
from typing import cast

from kctx.cli.result import Reply
from kctx.services.freshness import DRAIN_BUCKET_HINTS


def _mapping(value: object) -> Mapping[str, object]:
    if not isinstance(value, dict):
        raise TypeError("expected an encoded object")
    return cast(Mapping[str, object], value)


def _items(value: object) -> list[object]:
    if not isinstance(value, list):
        raise TypeError("expected an encoded array")
    return cast(list[object], value)


def _drain(value: object) -> None:
    result = _mapping(value)
    if not result["citations_available"]:
        print(f"citations unavailable: {result.get('note')}")
        return
    touched = _items(result["touched_files"])
    print(f"touched (fresh/moved/marked write-back): {len(touched)} file(s)")
    for raw_file in touched:
        file = _mapping(raw_file)
        for raw_change in _items(file["changes"]):
            change = _mapping(raw_change)
            print(f"  {file['file']}:{change['line_no']}")
            print(f"    - {change['before']}")
            print(f"    + {change['after']}")
    if result["total_remaining"] == 0:
        print("nothing remains")
    else:
        for bucket, raw_entries in _mapping(result["remaining"]).items():
            entries = _items(raw_entries)
            if not entries:
                continue
            print(f"{bucket} ({len(entries)}) -- {DRAIN_BUCKET_HINTS[bucket]}")
            for raw_entry in entries:
                entry = _mapping(raw_entry)
                print(f"  {entry['file']}:{entry['line_no']} ({entry['kind']})")
        print(f"-- {result['total_remaining']} item(s) remaining")
    corrections = result.get("open_corrections")
    if corrections:
        print(f"open corrections ({result['open_corrections_total']}):")
        for raw_row in _items(corrections):
            row = _mapping(raw_row)
            print(f"  {row['file']} -- {row['target']}: {row['referrer']} ({row['status']})")


def _proposal_list(value: object) -> None:
    proposals = _items(value)
    if not proposals:
        print("(none)")
        return
    headers = ["STATUS", "CREATED", "TYPE", "ORIGIN", "ID"]
    rows: list[list[str]] = []
    for raw_proposal in proposals:
        proposal = _mapping(raw_proposal)
        rows.append(
            [
                str(proposal.get("status", "")),
                str(proposal.get("created", "")),
                str(proposal.get("type", "") or ""),
                str(proposal.get("origin", "") or ""),
                str(proposal.get("id", "")),
            ]
        )
    widths = [len(header) for header in headers]
    for row in rows:
        for index, cell in enumerate(row):
            widths[index] = max(widths[index], len(cell))
    print("  ".join(header.ljust(widths[index]) for index, header in enumerate(headers)))
    print("  ".join("-" * width for width in widths))
    for row in rows:
        print("  ".join(cell.ljust(widths[index]) for index, cell in enumerate(row)))


def render_text(reply: Reply) -> None:
    result = reply.payload
    if reply.presentation == "drain":
        _drain(result)
    elif reply.presentation == "proposal-list":
        _proposal_list(result)
    elif reply.presentation == "proposal-single":
        proposal = _mapping(result)
        print(f"id: {proposal.get('id', '')}")
        print(f"path: {reply.path}")
        for missing in _items(proposal.get("missing", [])):
            print(f"missing for review: {missing}")
        for warning in _items(proposal.get("warnings", [])):
            print(f"warning: {warning}")
    elif isinstance(result, list):
        entries = cast(list[object], result)
        if not entries:
            print("(none)")
        for item in entries:
            if isinstance(item, dict):
                fields = cast(Mapping[str, object], item)
                print(" | ".join(f"{key}={value}" for key, value in fields.items()))
            else:
                print(item)
    elif isinstance(result, dict):
        for key, value in cast(Mapping[str, object], result).items():
            print(f"{key}: {value}")
    else:
        print(result)
