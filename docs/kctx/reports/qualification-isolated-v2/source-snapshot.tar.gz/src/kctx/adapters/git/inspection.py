"""Retain complete declared Git input bytes, detecting movement across capture.

The git-worktree-v1 profile includes HEAD, every index stage/blob, tracked
and non-ignored untracked worktree files, binary bytes, symlink targets,
permission modes and recursively initialized submodules. Ignored files are
outside this explicit profile. Two identical complete reads are required;
this detects observed movement, not an impossible lock-free ABA guarantee.
"""

import base64
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

from kctx.domain.capture import WorktreeCapture
from kctx.domain.ids import ContentDigest, GitRevision
from kctx.domain.json import JsonObject, JsonValue
from kctx.domain.time import iso_now
from kctx.errors import KctxError


def _git(root: Path, *arguments: str) -> bytes:
    try:
        result = subprocess.run(["git", "-C", str(root), *arguments], capture_output=True, check=False)
    except OSError as exc:
        raise KctxError("incomplete", f"cannot inspect Git source {root}: {exc}") from exc
    if result.returncode:
        raise KctxError("incomplete", f"cannot inspect Git source {root}: {result.stderr.decode(errors='replace').strip()}")
    return result.stdout


def _encoded(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _snapshot(root: Path, ancestors: frozenset[Path]) -> tuple[JsonObject, bool]:
    resolved = root.resolve()
    if resolved in ancestors:
        raise KctxError("malformed", f"recursive submodule at {root}")
    ancestors = ancestors | {resolved}
    revision = GitRevision(_git(root, "rev-parse", "--verify", "HEAD").decode("ascii").strip())
    # Normalize to the repository top so a locator inside a subdirectory does
    # not silently omit inputs outside that directory.
    top = Path(os.fsdecode(_git(root, "rev-parse", "--show-toplevel").rstrip(b"\n")))
    if top.resolve() != resolved:
        return _snapshot(top, ancestors - {resolved})
    status = _git(root, "status", "--porcelain=v1", "-z", "--untracked-files=all", "--ignore-submodules=none")
    index: list[JsonValue] = []
    blobs: JsonObject = {}
    gitlinks: set[bytes] = set()
    for record in _git(root, "ls-files", "--stage", "-z").split(b"\0"):
        if not record:
            continue
        metadata, path = record.split(b"\t", 1)
        mode, oid, stage = metadata.split(b" ")
        oid_text = oid.decode("ascii")
        index.append({"path_base64": _encoded(path), "mode": mode.decode("ascii"), "oid": oid_text, "stage": int(stage)})
        if mode == b"160000":
            gitlinks.add(path)
        elif oid_text not in blobs:
            blobs[oid_text] = _encoded(_git(root, "cat-file", "blob", oid_text))
    paths = set(_git(root, "ls-files", "--cached", "--others", "--exclude-standard", "-z").split(b"\0")) - {b""}
    worktree: list[JsonValue] = []
    for path in sorted(paths):
        full_path = root / os.fsdecode(path)
        entry: JsonObject = {"path_base64": _encoded(path)}
        try:
            info = full_path.lstat()
        except FileNotFoundError:
            entry["kind"] = "missing"
            worktree.append(entry)
            continue
        entry["mode"] = stat.S_IMODE(info.st_mode)
        if path in gitlinks:
            if not (full_path / ".git").exists():
                raise KctxError("incomplete", f"submodule input unavailable: {full_path}")
            nested, _ = _snapshot(full_path, ancestors)
            entry.update({"kind": "submodule", "snapshot": nested})
        elif stat.S_ISLNK(info.st_mode):
            entry.update({"kind": "symlink", "content_base64": _encoded(os.fsencode(os.readlink(full_path)))})
        elif stat.S_ISREG(info.st_mode):
            entry.update({"kind": "file", "content_base64": _encoded(full_path.read_bytes())})
        else:
            raise KctxError("incomplete", f"unsupported worktree input type: {full_path}")
        worktree.append(entry)
    return {"profile": "git-worktree-v1", "revision": revision.val, "index": index, "index_blobs": blobs, "worktree": worktree}, bool(status)


def capture_worktree(repo_path: str) -> WorktreeCapture:
    """Return retained stable input bytes, or an explicit unavailable/conflict error."""
    started_at = iso_now()
    root = Path(repo_path)
    try:
        first, first_dirty = _snapshot(root, frozenset())
        second, second_dirty = _snapshot(root, frozenset())
        final_revision = _git(root, "rev-parse", "--verify", "HEAD").decode("ascii").strip()
    except OSError as exc:
        raise KctxError("incomplete", f"Git source unavailable during capture: {repo_path}: {exc}") from exc
    if first != second or first_dirty != second_dirty or final_revision != first["revision"]:
        raise KctxError("conflict", f"Git source moved during capture: {repo_path}")
    payload = json.dumps(first, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    revision = first["revision"]
    if not isinstance(revision, str):
        raise KctxError("malformed", "captured Git revision is not text")
    return WorktreeCapture(GitRevision(revision), ContentDigest(hashlib.sha256(payload).hexdigest()),
                           payload, first_dirty, started_at, iso_now())
