#!/usr/bin/env python3
"""Disposable real-Dolt counterexamples. Prepared, not executed by the auditor.

Run from the checkout in its provisioned Python/Dolt environment:
    python /path/to/dolt_parity_repro.py --repo-root /path/to/kctx

Uses the repository's explicitly labelled container citation stub, not the real
production citation grammar. No mocked Dolt/parser calls. Leaves the temporary
fixture directory and real databases intact for inspection. Deliberately corrupts
ONLY its own temporary graph, then publishes the corrupt snapshot so the example
also applies when readers correctly pin the completed-generation reference.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=Path.cwd())
    parser.add_argument("--dolt", type=Path)
    parser.add_argument("--parser", type=Path)
    args = parser.parse_args()
    source = args.repo_root.resolve()
    sys.path.insert(0, str(source / "src"))
    citation_parser = (args.parser or source / "docker" / "cite_stub.py").resolve()
    if not citation_parser.is_file():
        raise FileNotFoundError(citation_parser)
    dolt = str(args.dolt.resolve()) if args.dolt else shutil.which("dolt")
    if dolt is None:
        candidate = Path.home() / ".local" / "bin" / "dolt"
        if candidate.is_file():
            dolt = str(candidate)
    if dolt is None:
        raise RuntimeError("real Dolt required; supply --dolt")

    from kctx.config import write_config
    from kctx.graph import queries, sync
    from kctx.graph.dolt_store import DoltStore, SYNC_STATE_COLUMNS
    from kctx.graph.extract import extract_graph, read_tree_at_sha
    from kctx.graph.quoting import sql_quote

    work = Path(tempfile.mkdtemp(prefix="kctx-parity-counterexamples-"))

    def command(argv: list[str], cwd: Path | None = None) -> str:
        return subprocess.run(argv, cwd=cwd, check=True, capture_output=True, text=True).stdout.strip()

    def fixture(name: str, files: dict[str, str]) -> tuple[Path, str]:
        home = work / name
        kb = home / "kb"
        kb.mkdir(parents=True)
        for relative, content in files.items():
            path = kb / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
        command(["git", "init", "-q", str(kb)])
        command(["git", "-C", str(kb), "add", "-A"])
        command(["git", "-C", str(kb), "-c", "user.name=Parity fixture", "-c", "user.email=parity@localhost", "commit", "-qm", name])
        sha = command(["git", "-C", str(kb), "rev-parse", "HEAD"])
        config = write_config(home / "config.toml", root=str(kb), graph_dir=str(home / "graph"), dolt_bin=dolt, log_dir=str(home / "logs"))
        os.environ["KCTX_CONFIG"] = str(config)
        return kb, sha

    original_rev = "a" * 40
    wrong_rev = "b" * 40
    original_target = "code:acme/source:src/a.py"
    wrong_target = "code:acme/source:src/b.py"
    original_token = f"⟦cite kind=code repo=acme/source path=src/a.py rev={original_rev} L=10-12⟧"
    other_token = f"⟦cite kind=code repo=acme/source path=src/b.py rev={original_rev} L=20-22⟧"
    kb, sha = fixture("binding-corruption", {"note.md": original_token + "\n" + other_token + "\n"})
    initial_sync = sync.sync(kb)
    initial_check = queries.check(kb)
    store = DoltStore(sync.dolt_db_dir())
    initial_rows = store.sql_read("SELECT edge_id,src_path,src_line,dst_node,rev,raw FROM edges WHERE rel='cites' ORDER BY src_line")

    # Deliberate data corruption, not a mocked store. Destination already exists,
    # so this does not depend on dangling-endpoint acceptance.
    store._run("sql", "-q", "UPDATE edges SET dst_node=" + sql_quote(wrong_target) + ", rev=" + sql_quote(wrong_rev) + " WHERE src_path='note.md' AND src_line=1 AND rel='cites'")
    corrupt_data_hash = store.commit("fixture: wrong target and revision, unchanged counts", allow_empty=True)
    state_rows = store.sql_read("SELECT * FROM sync_state WHERE id=1")
    if len(state_rows) != 1:
        raise RuntimeError("fixture requires exactly one sync_state row")
    state = state_rows[0]
    state["dolt_commit"] = corrupt_data_hash
    store.upsert_rows("sync_state", SYNC_STATE_COLUMNS, [state])
    corrupt_metadata_hash = store.commit("fixture: bind completed state to corrupt data", allow_empty=True)
    # Existing implementation reads WORKING; repaired storage reads this native
    # completed pointer. Both now select the deliberately corrupted generation.
    store._run("branch", "-f", "kctx-complete", corrupt_metadata_hash)
    corrupted_rows = store.sql_read("SELECT edge_id,src_path,src_line,dst_node,rev,raw FROM edges AS OF " + sql_quote(corrupt_data_hash) + " WHERE rel='cites' ORDER BY src_line")
    corrupt_check = queries.check(kb)
    first_wrong = [row for row in corrupted_rows if row.get("src_line") in (1, "1")]
    binding_reproduced = bool(first_wrong) and first_wrong[0].get("dst_node") == wrong_target and first_wrong[0].get("rev") == wrong_rev and corrupt_check["parity"]["match"] is True

    # Separate fixture: JSON token omissions should not contaminate the count-
    # preservation counterexample above. Long raw token has only one citation.
    long_token = f"⟦cite kind=code repo=acme/source path=src/long.py rev={original_rev} L=33-35 note=" + "x" * 650 + "⟧"
    asset_token = "⟦cite kind=ticket id=ASSET-1 seen=2026-10-30T00:00Z⟧"
    relationship_token = "⟦cite kind=ticket id=REL-1 seen=2026-10-30T00:00Z⟧"
    asset = {"id": "service-a", "kind": "service", "name": "A", "locator": "acme/source", "owner": "fixture", "owner_source": "fixture", "schema_version": 1, "notes": asset_token}
    second_asset = {**asset, "id": "service-b", "name": "B", "notes": ""}
    relationship = {"id": "depends-on__service-a__service-b", "from": "service-a", "to": "service-b", "type": "depends-on", "status": "explicit", "schema_version": 1, "evidence": [relationship_token]}
    files = {
        "note.md": original_token + "\n" + long_token + "\n",
        "inventory/assets/service-a.json": json.dumps(asset, ensure_ascii=False) + "\n",
        "inventory/assets/service-b.json": json.dumps(second_asset, ensure_ascii=False) + "\n",
        "inventory/relationships/depends-on__service-a__service-b.json": json.dumps(relationship, ensure_ascii=False) + "\n",
    }
    extraction_kb, extraction_sha = fixture("extraction-loss", files)
    extraction_sync = sync.sync(extraction_kb)
    extraction_store = DoltStore(sync.dolt_db_dir())
    extraction_rows = extraction_store.sql_read("SELECT * FROM edges WHERE rel='cites' ORDER BY src_path,src_line")
    extracted = extract_graph(read_tree_at_sha(extraction_kb, extraction_sha), extraction_sha, "2026-10-30T00:00:00Z", extraction_kb)
    long_rows = [row for row in extraction_rows if row.get("src_path") == "note.md" and row.get("src_line") in (2, "2")]
    note_rows = [row for row in extraction_rows if row.get("src_path") == "note.md" and row.get("src_line") in (1, "1")]
    missing_paths = [path for path in ("inventory/assets/service-a.json", "inventory/relationships/depends-on__service-a__service-b.json") if not any(row.get("src_path") == path and row.get("rel") == "cites" for row in extraction_rows)]
    extraction_check = queries.check(extraction_kb)
    report = {
        "fixture_root": str(work),
        "tool_versions": {"dolt": command([dolt, "version"]), "git": command(["git", "--version"]), "python": sys.version},
        "parser": {"qualification": "built-in kctx citation grammar imported from the supplied source"},
        "binding_corruption": {
            "kb_root": str(kb), "kb_sha": sha, "source_token": original_token,
            "expected_binding": {"dst_node": original_target, "rev": original_rev, "L": "10-12"},
            "initial_sync": initial_sync, "initial_check": initial_check, "initial_rows": initial_rows,
            "corrupt_data_hash": corrupt_data_hash, "corrupt_metadata_hash": corrupt_metadata_hash,
            "corrupted_rows_at_exact_commit": corrupted_rows, "actual_graph_check": corrupt_check,
            "false_positive_reproduced": binding_reproduced,
        },
        "extraction_loss": {
            "kb_root": str(extraction_kb), "kb_sha": extraction_sha, "sync": extraction_sync,
            "expected_source_tokens": 4, "source_tokens": [original_token, long_token, asset_token, relationship_token],
            "actual_binding_rows": extraction_rows,
            "line_range_expected": "10-12", "first_code_binding": note_rows,
            "long_token_length": len(long_token), "stored_long_token_length": len(str(long_rows[0].get("raw") or "")) if long_rows else None,
            "missing_json_citation_paths": missing_paths,
            "extractor_tokens_seen": extracted.stats.cite_tokens_seen,
            "extractor_recorded_drops": extracted.stats.cite_tokens_dropped,
            "actual_graph_check": extraction_check,
        },
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if binding_reproduced else 1


if __name__ == "__main__":
    raise SystemExit(main())
