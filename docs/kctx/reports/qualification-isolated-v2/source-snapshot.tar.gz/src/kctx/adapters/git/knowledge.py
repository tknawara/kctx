"""Immutable Git release manifests with an expected-predecessor CAS."""
from __future__ import annotations

from pathlib import Path
import subprocess

from kctx.adapters.files.knowledge import canonical, decode
from kctx.domain.json import JsonObject
from kctx.errors import KctxError

RELEASE_REF = "refs/kctx/knowledge"


class GitReleases:
    def __init__(self, repo: Path) -> None:
        self.repo = repo.resolve()
        self.run("rev-parse", "--git-dir")
        self.common = Path(self.run("rev-parse", "--path-format=absolute", "--git-common-dir").strip())

    def run(self, *args: str, data: bytes | None = None) -> str:
        result = subprocess.run(["git", "-C", str(self.repo), *args], input=data, capture_output=True, check=False)
        if result.returncode:
            raise KctxError("conflict", result.stderr.decode(errors="replace").strip())
        return result.stdout.decode()

    def current(self) -> str | None:
        result = subprocess.run(["git", "-C", str(self.repo), "rev-parse", "--verify", "--quiet", RELEASE_REF], capture_output=True, check=False)
        if result.returncode == 1:
            return None
        if result.returncode:
            raise KctxError("malformed", result.stderr.decode(errors="replace"))
        return result.stdout.decode().strip()

    def manifest(self, revision: str) -> JsonObject:
        if len(revision) not in (40, 64) or any(c not in "0123456789abcdef" for c in revision):
            raise KctxError("malformed", "release must be an exact Git object identity")
        return decode(self.run("show", f"{revision}:manifest.json").encode())

    def prepare(self, manifest: JsonObject, predecessor: str | None, artifacts: dict[str, bytes]) -> str:
        blob = self.run("hash-object", "-w", "--stdin", data=canonical(manifest)).strip()
        entries: list[str] = []
        for identity, data in sorted(artifacts.items()):
            if len(identity) != 64 or any(c not in "0123456789abcdef" for c in identity):
                raise KctxError("malformed", "invalid retained artifact identity")
            obj = self.run("hash-object", "-w", "--stdin", data=data).strip()
            entries.append(f"100644 blob {obj}\t{identity}\n")
        artifact_tree = self.run("mktree", data="".join(entries).encode()).strip()
        tree = self.run("mktree", data=f"100644 blob {blob}\tmanifest.json\n040000 tree {artifact_tree}\tartifacts\n".encode()).strip()
        parents = ["-p", predecessor] if predecessor else []
        return self.run("-c", "user.name=kctx-knowledge", "-c", "user.email=kctx@localhost", "commit-tree", tree, *parents, "-m", "Publish approved knowledge generation").strip()

    def artifact(self, revision: str, identity: str) -> bytes:
        if len(identity) != 64 or any(c not in "0123456789abcdef" for c in identity):
            raise KctxError("malformed", "invalid retained artifact identity")
        result = subprocess.run(["git", "-C", str(self.repo), "show", f"{revision}:artifacts/{identity}"], capture_output=True, check=False)
        if result.returncode:
            raise KctxError("not-found", "retained source artifact is missing")
        return result.stdout

    def publish(self, revision: str, predecessor: str | None) -> None:
        self.run("update-ref", RELEASE_REF, revision, predecessor or ("0" * len(revision)))
