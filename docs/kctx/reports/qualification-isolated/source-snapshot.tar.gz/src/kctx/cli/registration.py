"""Register the public command-line grammar."""

import argparse
from typing import Protocol

from kctx.citations.cli import register as register_citations


class ParserRegistrar(Protocol):
    """Public subset needed by independently registered command families."""

    def add_parser(self, name: str, *, help: str) -> argparse.ArgumentParser: ...


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="kctx")
    p.add_argument(
        "--json",
        action="store_true",
        help="emit structured JSON instead of readable text",
    )
    sub = p.add_subparsers(dest="command", required=True)
    register_citations(sub.add_parser("cite", help="make, check, scan, and render citations"))
    from kctx.cli.knowledge import register as register_knowledge

    register_knowledge(sub)

    sub.add_parser("validate", help="validate inventory/proposal/run records")

    asset_p = sub.add_parser("asset")
    asset_sub = asset_p.add_subparsers(dest="asset_command", required=True)

    a_add = asset_sub.add_parser("add")
    a_add.add_argument("--kind", required=True)
    a_add.add_argument("--name", required=True)
    a_add.add_argument("--id")
    a_add.add_argument("--alias", dest="aliases", action="append", default=[])
    a_add.add_argument("--locator", default="")
    a_add.add_argument("--owner", default="unknown")
    a_add.add_argument("--owner-source", dest="owner_source", default="")
    a_add.add_argument("--lifecycle", default="active")
    a_add.add_argument("--inspect", default="")
    a_add.add_argument("--project", dest="projects", action="append", default=[])
    a_add.add_argument("--verified-at", dest="verified_at")
    a_add.add_argument("--ttl")
    a_add.add_argument("--notes", default="")

    a_show = asset_sub.add_parser("show")
    a_show.add_argument("ident")

    a_list = asset_sub.add_parser("list")
    a_list.add_argument("--kind")
    a_list.add_argument("--project")

    rel_p = sub.add_parser("rel")
    rel_sub = rel_p.add_subparsers(dest="rel_command", required=True)
    r_add = rel_sub.add_parser("add")
    r_add.add_argument("--type", required=True)
    r_add.add_argument("--from", dest="from_", required=True)
    r_add.add_argument("--to", required=True)
    r_add.add_argument("--id")
    r_add.add_argument("--status", default="explicit")
    r_add.add_argument("--evidence", dest="evidence", action="append", default=[])
    r_add.add_argument("--applicability", default="")

    impact_p = sub.add_parser("impact")
    impact_p.add_argument("asset")
    impact_p.add_argument("--depth", type=int, default=2)

    home_p = sub.add_parser("home")
    home_p.add_argument("ident")

    context_p = sub.add_parser("context")
    context_p.add_argument("ident")
    context_p.add_argument("--depth", type=int, default=2)

    stale_p = sub.add_parser("stale")
    stale_p.add_argument("--project")
    stale_p.add_argument(
        "--offline",
        action="store_true",
        help="no network: cite stale --offline plus kctx's own offline checks",
    )
    stale_p.add_argument(
        "--drain",
        action="store_true",
        help="write back cite check --touch --mark, then report remaining judgment items",
    )
    stale_p.add_argument(
        "paths",
        nargs="*",
        help="explicit paths for --drain when --project is not given",
    )

    admit_p = sub.add_parser("admit")
    admit_p.add_argument(
        "pr_ref", nargs="?", help="PR url or org/repo#N, as a shortcut for --repo"
    )
    admit_p.add_argument("--repo", help="org/repo to sweep from its cursor to head")
    admit_p.add_argument(
        "--since", help="sha or date; required the first time --repo has no cursor"
    )
    admit_p.add_argument("--dry-run", dest="dry_run", action="store_true")

    dossier_p = sub.add_parser("dossier")
    dossier_sub = dossier_p.add_subparsers(dest="dossier_command", required=True)
    d_new = dossier_sub.add_parser("new")
    d_new.add_argument("asset")
    d_archive = dossier_sub.add_parser("archive")
    d_archive.add_argument("asset")
    d_archive.add_argument("--force", action="store_true")

    ktlo_p = sub.add_parser("ktlo")
    ktlo_sub = ktlo_p.add_subparsers(dest="ktlo_command", required=True)
    k_new = ktlo_sub.add_parser("new")
    k_new.add_argument("ticket")
    k_new.add_argument("--title", required=True)
    k_new.add_argument("--asset", dest="assets", action="append", default=[])
    k_promote = ktlo_sub.add_parser("promote")
    k_promote.add_argument("ticket")
    k_promote.add_argument("project")

    inv_p = sub.add_parser("inv")
    inv_sub = inv_p.add_subparsers(dest="inv_command", required=True)
    i_new = inv_sub.add_parser("new")
    i_new.add_argument("slug")
    i_new.add_argument("--trigger", required=True)
    i_new.add_argument("--title")
    i_new.add_argument("--ticket", dest="tickets", action="append", default=[])
    i_new.add_argument("--alert", dest="alerts", action="append", default=[])
    i_new.add_argument("--asset", dest="assets", action="append", default=[])
    i_new.add_argument("--window", dest="windows", action="append", default=[])
    i_new.add_argument("--impact-summary", dest="impact_summary", default="")
    i_new.add_argument(
        "--created",
        help="backfill a historical creation date (YYYY-MM-DD); defaults to today",
    )
    i_list = inv_sub.add_parser("list")
    i_list.add_argument("--open", dest="open_only", action="store_true")
    i_list.add_argument("--asset")
    i_show = inv_sub.add_parser("show")
    i_show.add_argument("id")
    i_conclude = inv_sub.add_parser("conclude")
    i_conclude.add_argument("id")
    i_promote = inv_sub.add_parser("promote")
    i_promote.add_argument("id")
    i_promote.add_argument("project")

    sig_p = sub.add_parser("sig")
    sig_sub = sig_p.add_subparsers(dest="sig_command", required=True)
    s_new = sig_sub.add_parser("new")
    s_new.add_argument("slug")
    s_new.add_argument("--title")
    s_new.add_argument("--match", dest="match", action="append", default=[])
    s_new.add_argument("--match-where", dest="match_where", default="")
    s_new.add_argument("--asset", dest="assets", action="append", default=[])
    s_new.add_argument("--owner-group", dest="owner_group")
    s_new.add_argument("--status", default="suspected")
    s_new.add_argument("--first-seen", dest="first_seen")
    s_new.add_argument("--last-seen", dest="last_seen")
    s_new.add_argument("--workaround", default="")
    s_new.add_argument("--fix", dest="fix", action="append", default=[])
    s_new.add_argument("--fixed-at", dest="fixed_at")
    s_new.add_argument("--verified-at", dest="verified_at")
    s_new.add_argument("--ttl")
    sig_sub.add_parser("list")
    s_show = sig_sub.add_parser("show")
    s_show.add_argument("id")

    match_p = sub.add_parser("match")
    match_p.add_argument("text")

    timeline_p = sub.add_parser("timeline")
    timeline_p.add_argument("ident")

    uses_p = sub.add_parser("uses")
    uses_p.add_argument("target")

    retract_p = sub.add_parser("retract")
    retract_p.add_argument("target")
    retract_p.add_argument("--reason", required=True)
    retract_p.add_argument(
        "--kind", required=True, choices=sorted(["retract", "dispute", "supersede"])
    )
    retract_p.add_argument("--by-replacement", dest="by_replacement")
    retract_p.add_argument("--operation-id", help="stable correction identity; retries must retain exact input")

    correction_p = sub.add_parser("correction")
    correction_sub = correction_p.add_subparsers(dest="correction_command", required=True)
    correction_sub.add_parser("recover", help="replay durable correction target and review-task projections")

    run_p = sub.add_parser("run")
    run_sub = run_p.add_subparsers(dest="run_command", required=True)
    rn = run_sub.add_parser("new")
    rn.add_argument("--project", required=True)
    rn.add_argument(
        "--mode", required=True, choices=sorted(["advice", "review", "authoring"])
    )
    rn.add_argument("--task", required=True)

    observe_p = sub.add_parser("observe")
    observe_p.add_argument("run")
    observe_p.add_argument("--system", required=True)
    observe_p.add_argument("--locator", required=True)
    observe_p.add_argument("--asset")
    observe_p.add_argument("--revision")
    observe_p.add_argument("--role", default="note")
    observe_p.add_argument("--status", default="ok")
    observe_p.add_argument("--cmd", dest="observed_command")
    observe_p.add_argument("--environment")
    observe_p.add_argument("--evidence")
    observe_p.add_argument("--note")
    observe_p.add_argument("--derived-from", action="append", default=[], help="observation ID whose evidence this result derives from")

    cover_p = sub.add_parser("cover")
    cover_p.add_argument("run")
    cover_p.add_argument("--item", required=True)
    cover_p.add_argument("--outcome", required=True)
    cover_p.add_argument("--evidence", dest="evidence", action="append", default=[])
    cover_p.add_argument("--reason", default="")
    cover_p.add_argument("--policy", choices=["single-source", "independent-origins"], default="single-source",
                         help="named support policy; independent-origins requires at least two disjoint known provenance roots")

    check_p = sub.add_parser("check")
    check_p.add_argument("run")
    check_p.add_argument("--require", dest="require", action="append", default=[])

    resume_p = sub.add_parser("resume")
    resume_p.add_argument("run")

    checkpoint_p = sub.add_parser("checkpoint")
    checkpoint_p.add_argument("run")
    checkpoint_p.add_argument("--note", required=True)

    proposal_p = sub.add_parser("proposal")
    proposal_sub = proposal_p.add_subparsers(dest="proposal_command", required=True)

    p_add = proposal_sub.add_parser("add")
    p_add.add_argument("--kind", required=True)
    p_add.add_argument("--origin", required=True)
    p_add.add_argument("--type", dest="type", action="append", default=[])
    p_add.add_argument("--title", required=True)
    p_add.add_argument("--target", dest="target", action="append", default=[])
    p_add.add_argument("--context", required=True)
    p_add.add_argument("--evidence", required=True)
    p_add.add_argument("--change", required=True)
    p_add.add_argument("--why", required=True)
    p_add.add_argument("--research", default="")
    p_add.add_argument("--alternatives", default="")
    p_add.add_argument(
        "--gates", default="", help="a markdown table, or a path to a file holding one"
    )
    p_add.add_argument("--impact", default="")
    p_add.add_argument("--plan", default="")
    p_add.add_argument("--ref", dest="references", action="append", default=[])
    p_add.add_argument("--project")
    p_add.add_argument("--session", dest="source_session")
    p_add.add_argument("--proposed-by", dest="proposed_by")
    p_add.add_argument("--requested-by", dest="requested_by")
    p_add.add_argument("--force", action="store_true")
    p_add.add_argument("--target-revision")
    p_add.add_argument("--environment", help="explicit gate environment; absent means unknown")
    p_add.add_argument("--scope", help="explicit gate applicability scope; absent means unknown")

    p_list = proposal_sub.add_parser("list")
    p_list.add_argument("--status")
    p_list.add_argument("--kind")
    p_list.add_argument("--pending-gates", dest="pending_gates", action="store_true")

    p_set = proposal_sub.add_parser("set")
    p_set.add_argument("id")
    p_set.add_argument("--status")
    p_set.add_argument("--by")
    p_set.add_argument("--note")
    p_set.add_argument("--superseded-by", dest="superseded_by")
    p_set.add_argument("--origin")
    p_set.add_argument("--proposed-by", dest="proposed_by")
    p_set.add_argument("--requested-by", dest="requested_by")
    p_set.add_argument("--swept-at", dest="swept_at")
    p_set.add_argument("--landed", dest="landed_add", action="append", default=None)
    p_set.add_argument("--target-revision")
    p_set.add_argument("--expected-revision", help="proposal source revision returned by show")
    p_set.add_argument("--environment")
    p_set.add_argument("--scope")

    p_gate = proposal_sub.add_parser("gate")
    p_gate.add_argument("id")
    p_gate.add_argument("gate")
    p_gate.add_argument("--outcome", required=True, choices=["pass", "fail", "unk"])
    p_gate.add_argument("--evidence", required=True)
    p_gate.add_argument("--by")
    p_gate.add_argument("--rev")
    p_gate.add_argument("--target-revision")
    p_gate.add_argument("--checker", required=True)
    p_gate.add_argument("--expires-at", required=True, help="inclusive UTC epoch-second expiry")
    p_gate.add_argument("--expected-revision", help="proposal source revision returned by show")
    p_gate.add_argument("--environment")
    p_gate.add_argument("--scope")

    p_show = proposal_sub.add_parser("show")
    p_show.add_argument("id")

    # Graph dependencies are optional in a bare checkout interpreter.
    try:
        from kctx.graph.cli_graph import add_graph_subparser
        from kctx.observability import add_logs_subparser
    except ImportError:
        pass
    else:
        add_graph_subparser(sub)
        add_logs_subparser(sub)

    return p
