"""Application entry point shared by installed and module invocations."""

import json
import sys
from collections.abc import Sequence

from kctx.adapters.files.roots import find_root
from kctx.cli.arguments import Arguments
from kctx.cli.dispatch import dispatch
from kctx.cli.registration import build_parser
from kctx.cli.rendering import render_text
from kctx.errors import KctxError


def main(argv: Sequence[str] | None = None) -> int:
    raw_arguments = list(sys.argv[1:] if argv is None else argv)
    verbose = any(value in ("-v", "--verbose") for value in raw_arguments)
    clean_arguments = [value for value in raw_arguments if value not in ("-v", "--verbose")]
    try:
        from kctx.observability import init_logging
    except ImportError:
        pass
    else:
        init_logging(verbose=verbose)
    args = Arguments(build_parser().parse_args(clean_arguments))
    as_json = args.flag("json")
    try:
        if args.text("command") == "cite":
            from kctx.citations.cli import dispatch as dispatch_citations
            from kctx.citations.cli import render_text as render_citations
            result, code = dispatch_citations(args)
            if as_json:
                print(json.dumps(result, indent=2))
            else:
                render_citations(result, args.text("cite_command"))
            return code
        reply = dispatch(args, find_root())
    except KctxError as exc:
        if as_json:
            print(json.dumps({"error": exc.category, "message": exc.message}))
        else:
            print(f"error ({exc.category}): {exc.message}", file=sys.stderr)
        return 1
    if as_json:
        print(json.dumps(reply.payload, indent=2))
    elif reply.presentation == "graph":
        from kctx.graph.render import render_graph_text
        render_graph_text(args.namespace, reply.payload)
    else:
        render_text(reply)
    return reply.code
