"""Incident workflow commands and their nominal identity boundaries."""

from pathlib import Path

from kctx.cli.arguments import Arguments
from kctx.cli.result import Reply
from kctx.domain.ids import AssetId, InvestigationId, OperationId, SignatureId, ProposalId
from kctx.domain.vocabulary import InvestigationTrigger, SignatureStatus, CorrectionKind
from kctx.errors import KctxError
from kctx.services import investigations, signatures, ktlo, dossiers, corrections


def dispatch(args: Arguments, root: Path) -> Reply:
    command = args.text("command")
    if command == "dossier":
        asset = args.parsed("asset", AssetId)
        if args.text("dossier_command") == "new":
            return Reply(dossiers.result_to_wire(dossiers.new(root, asset)))
        return Reply(dossiers.result_to_wire(dossiers.archive(root, asset, force=args.flag("force"))))
    if command == "ktlo":
        ticket = args.parsed("ticket", ktlo.normalize_ticket)
        if args.text("ktlo_command") == "new":
            return Reply(ktlo.result_to_wire(ktlo.new(
                root, ticket=ticket, title=args.text("title"), assets=args.many("assets", AssetId),
            )))
        return Reply(ktlo.result_to_wire(ktlo.promote(root, ticket, args.text("project"))))
    if command == "inv":
        action = args.text("inv_command")
        if action == "new":
            return Reply(investigations.result_to_wire(investigations.new(
                root, args.text("slug"), trigger=args.parsed("trigger", InvestigationTrigger),
                title=args.optional("title"), tickets=args.many("tickets", ktlo.normalize_ticket),
                alerts=args.many("alerts", AssetId), assets=args.many("assets", AssetId),
                windows=args.strings("windows"), impact_summary=args.text("impact_summary"), created=args.optional("created"),
            )))
        if action == "list":
            entries = investigations.list_investigations(root, open_only=args.flag("open_only"), asset=args.optional_parsed("asset", AssetId))
            return Reply([investigations.frontmatter_to_wire(entry) for entry in entries])
        investigation_id = args.parsed("id", InvestigationId)
        if action == "show":
            return Reply(investigations.result_to_wire(investigations.show(root, investigation_id)))
        if action == "conclude":
            return Reply(investigations.result_to_wire(investigations.conclude(root, investigation_id)))
        if action == "promote":
            return Reply(investigations.result_to_wire(investigations.promote(root, investigation_id, args.text("project"))))
    if command == "sig":
        action = args.text("sig_command")
        if action == "new":
            return Reply(signatures.result_to_wire(signatures.new(
                root, args.text("slug"), title=args.optional("title"), match=args.strings("match"),
                match_where=args.text("match_where"), assets=args.many("assets", AssetId),
                owner_group=args.optional("owner_group"), status=args.parsed("status", SignatureStatus),
                first_seen=args.optional("first_seen"), last_seen=args.optional("last_seen"),
                workaround=args.text("workaround"), fix=args.many("fix", ProposalId), fixed_at=args.optional("fixed_at"),
                verified_at=args.optional("verified_at"), ttl=args.optional("ttl"),
            )))
        if action == "list":
            return Reply([signatures.frontmatter_to_wire(entry) for entry in signatures.list_signatures(root)])
        if action == "show":
            return Reply(signatures.result_to_wire(signatures.show(root, args.parsed("id", SignatureId))))
    if command == "retract":
        return Reply(corrections.result_to_wire(corrections.retract(
            root, args.parsed("target", corrections.parse_correction_target), reason=args.text("reason"),
            kind=args.parsed("kind", CorrectionKind), by_replacement=args.optional("by_replacement"),
            operation_id=args.optional_parsed("operation_id", OperationId),
        )))
    if command == "correction" and args.text("correction_command") == "recover":
        return Reply({"operations": [corrections.result_to_wire(result) for result in corrections.recover(root)]})
    raise KctxError("malformed", f"unhandled incident command {command!r}")
