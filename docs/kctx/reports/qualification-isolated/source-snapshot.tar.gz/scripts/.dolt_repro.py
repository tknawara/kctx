"""Run BEFORE storage repair: real temporary Dolt/Git, no publication/remotes."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import subprocess

from kctx.graph.dolt_store import DoltStore, EDGE_COLUMNS, NODE_COLUMNS, SYNC_STATE_COLUMNS
from kctx.graph.models import Edge, GraphNodeId
from kctx.graph import queries, sync


def git(root: Path, *args: str) -> str:
    return subprocess.run(["git", "-C", str(root), *args], check=True, capture_output=True, text=True).stdout.strip()


def state(store: DoltStore, sha: str, commit: str | None) -> None:
    store.upsert_rows("sync_state", SYNC_STATE_COLUMNS, [{"id": 1, "kb_sha": sha,
        "kb_subject": "fixture", "dolt_commit": commit, "synced_at": "2026-10-31T00:00:00Z",
        "node_count": 0, "edge_count": 1}])


with TemporaryDirectory(prefix="kctx-dolt-repro-") as temporary:
    base = Path(temporary)
    root = base / "kb"
    root.mkdir()
    git(root, "init", "-q")
    git(root, "-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid", "commit", "--allow-empty", "-qm", "fixture")
    sha = git(root, "rev-parse", "HEAD")
    db = base / "graph" / "dolt"
    store = DoltStore(db)
    store.ensure_init()
    state(store, sha, None)
    with patch.object(sync, "dolt_db_dir", return_value=db):
        result = sync.sync(root)
    print("INCOMPLETE_FALSE_CURRENT", result)
    assert result["status"] == "up-to-date" and result["dolt_commit"] is None

    store.replace_table("nodes", NODE_COLUMNS, [{"id": "source", "kind": "doc", "label": "source", "home_path": "source.md"}])
    row = Edge.from_row({"edge_id": "fixture", "src_node": "source", "dst_node": "old-target", "rel": "mentions", "cite_kind": "doc", "seen": "2026-10-31"}).to_wire()
    store.replace_table("edges", EDGE_COLUMNS, [row])
    data_commit = store.commit("fixture data", allow_empty=True)
    state(store, sha, data_commit)
    completed = store.commit("fixture completed", allow_empty=True)
    store._run("sql", "-q", "UPDATE edges SET dst_node='target' WHERE edge_id='fixture'")
    with patch.object(queries, "_store", return_value=store):
        result = queries.uses(GraphNodeId("target"))
    print("WORKING_LEAK", result)
    assert result["total"] == 1

    other = base / "other-kb"
    subprocess.run(["git", "clone", "-q", str(root), str(other)], check=True)
    with patch.object(sync, "dolt_db_dir", return_value=db):
        result = sync.sync(other)
    print("CROSS_KB_FALSE_CURRENT", result)
    assert result["status"] == "up-to-date"

    store.rebuild()
    old_commit = subprocess.run([store.dolt_bin, "show", completed], cwd=db, capture_output=True, text=True)
    print("REBUILD_HISTORY_LOST", old_commit.returncode, old_commit.stderr.strip())
    assert old_commit.returncode != 0

print("All four source counterexamples reproduced; temporary repositories removed.")
