"""Shared error type for kctx.

Every command raises KctxError for expected failures (not found, malformed
records, stale inputs, write conflicts, incomplete evidence, permission and
timeout problems) so the CLI can report a stable category instead of a raw
traceback.
"""

from typing import Literal, TypeAlias

from kctx.redaction import mask_secrets

ErrorCategory: TypeAlias = Literal[
    "not-found", "malformed", "stale", "conflict", "incomplete", "permission", "timeout"
]

CATEGORIES: frozenset[ErrorCategory] = frozenset(
    {"not-found", "malformed", "stale", "conflict", "incomplete", "permission", "timeout"}
)


class KctxError(Exception):
    def __init__(self, category: ErrorCategory, message: str) -> None:
        if category not in CATEGORIES:
            raise ValueError(f"unknown error category {category!r}")
        safe_message = mask_secrets(message)
        super().__init__(safe_message)
        self.category = category
        self.message = safe_message
